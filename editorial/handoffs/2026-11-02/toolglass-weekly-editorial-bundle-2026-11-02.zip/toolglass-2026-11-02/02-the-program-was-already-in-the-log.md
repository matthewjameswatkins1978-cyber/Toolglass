---
title: The Program Was Already in the Log
slug: the-program-was-already-in-the-log
section: Ideas / Programming Models
article_type: Feature
status: EDITORIAL DRAFT — NOT APPROVED OR PUBLISHED
evidence_status: PRIMARY-PAPER DESK RESEARCH; NOT HANDS-ON
editor: Lucy
prepared: 2 November 2026
art: art/the-unwritten-program.webp
---

# The Program Was Already in the Log

## We taught computers to record what happened. A new line of research asks whether the record can become a program, including the decisions nobody explicitly wrote down.

*Toolglass / Feature draft for Matthew's editorial pass / 2 November 2026*

A computer can remember that you pressed the button to stop a server. It can remember that the server did not stop. It can remember that you looked at the status, frowned, and pressed the button again, this time with the force option enabled.

The frown is not in the log. The reason for the second button press probably is not either. What remains is a sequence of requests and responses, a little mechanical diary of what happened. To an administrator, it is evidence. To a monitoring system, it is something to search when the pager goes off at three in the morning.

But there is another possibility. What if the log is not merely a record of the job? What if it is an unfinished description of how to do the job again?

That is the question behind *Incremental Program Synthesis from Event Logs*, a paper by Jinwoo Kim, Victor Nicolet, Joey Dodds and Loris D'Antoni presented at OOPSLA on 5 October 2026. Their research system, **LogLoom**, tries to construct small automation programs from the structured event logs that software systems already collect. The headline result is striking: in the authors' benchmark, LogLoom recovered the intended program structure in 60 of 72 tasks, compared with 14 for a previous symbolic technique and up to 39 for the language-model baselines. Those are the authors' results, not independent Toolglass tests, and the meaning of *intended* deserves examination. [1][2]

The more interesting story is older than the paper. For half a century, computer researchers have been trying to remove the gap between *doing something* and *telling a computer how to do it*. LogLoom belongs to that family, but approaches the problem from a peculiar direction. It does not sit over your shoulder waiting for a demonstration. It looks through the footprints after you have gone home.

> **PULL QUOTE 01 / TOOLGLASS EDITORIAL**
> A log remembers the steps. A useful program has to discover the reason for the fork in the road.
>
> *Toolglass / original editorial line, not a quotation from the researchers*

## Act I / The recorder and the missing intention

The oldest form of this idea is the macro recorder. You perform an action, the machine records it, and later the machine plays it back. This is wonderful until the world changes. If a macro clicks the seventh row in a table, what happens when the wanted item moves to the eighth? If it types a filename, what happens when tomorrow's file has a different name? A recording is faithful to the past, not necessarily useful in the future.

Researchers called the broader ambition *programming by demonstration* or *programming by example*. David Canfield Smith's 1975 *Pygmalion* thesis explored programming through visible objects and examples. In the 1980s and 1990s, systems including Eager and the work collected in Allen Cypher's *Watch What I Do* tried to infer patterns from a user's behaviour. Some approaches watched actions as they occurred; others took example inputs and outputs and searched for a transformation that connected them. They shared an almost impolite question: why should a person have to learn a programming language just to teach a machine something the person can already do? [3][4]

The difficulty was never just recording the demonstration. It was **generalising** it. The computer had to distinguish the incidental from the essential. The particular spreadsheet cell was incidental; finding the next unpaid invoice was essential. The precise server identifier was incidental; stopping the server the user selected was essential. And sometimes the demonstration was itself an accident, a bad habit or an emergency exception. An automation that faithfully learns an accident is not intelligent. It is a very reliable way to repeat an accident.

LogLoom's source material is even thinner than a demonstration. The paper focuses on structured logs of API calls: the name of an operation, its input arguments and its output. A graphical interface might have generated them, or a human-written script. The log can tell us that `StopInstances` was called, then `DescribeInstanceStatus`, then perhaps `StopInstances` again. It does not explicitly contain the `if` statement that made the second call conditional. It does not necessarily say what the program's input parameter was. It does not show the unexecuted branch. [1]

A single trace therefore supports many possible programs. Perhaps the second stop call always happens. Perhaps it happens only on Tuesdays. Perhaps it happens when the first request fails. A programmer can read the result of the status check and make a plausible inference, but a machine cannot simply assume that plausibility is a proof.

The central technical problem is to move from **an observed path** to **a reusable control structure**. That is a bigger leap than copying commands into a shell script.

## Act II / Building the branch that was never written

The authors begin with a small program and add one log at a time. Suppose the first log shows two calls: stop the server, inspect its status. An initial script can reproduce those calls. Now a second log arrives in which the first stop attempt does not complete, the status check reports that fact, and a forced stop follows.

A crude synthesiser could produce two hard-coded scripts and choose between them. That would fit the examples while missing the underlying rule. The desirable result is a program that accepts a server identifier, stops that server, checks the result and invokes the forced stop **only when the status requires it**. It must work for identifiers and circumstances not present in the training logs. [1]

LogLoom represents a candidate script as a *control-flow graph*: nodes for API calls, branches, assignments and loops; edges for the possible routes between them. This is a technical term for a familiar object. A road map shows the junctions and possible journeys. A control-flow graph shows where a program can go and which conditions let it take each road.

When a new log arrives, the system first looks for a route through the existing graph with the same sequence of API names. It deliberately ignores the particular arguments during this first search. If a route already exists, perhaps only a condition or parameter expression needs repairing. If no route can produce that sequence, the graph itself needs another junction or operation. The paper calls the latter search *lenient path matching*. [1]

The clever part is how the system tries to make the smallest useful change. It uses constraint solving, including Max-SMT, to locate expressions that prevent the current program from matching the new log. It then formulates a smaller input-output synthesis problem for an external synthesiser. The result is not an LLM guessing what the operator probably meant. It is a series of constrained searches over candidate program paths and expressions, with the log's recorded API events as requirements. [1]

This does not mean that every inferred condition is the operator's true intention. It means that the program must reproduce the evidence under the model the researchers have defined. The distinction is vital. The paper's correctness claims concern consistency with the supplied traces and the synthesis formalism. They are not a universal guarantee that an inferred script is safe, authorised or wise in an unseen production environment.

There is also an important reason for adding the logs one by one. Earlier symbolic work, notably Syren, repeatedly transformed a whole collection of traces into a program. That approach can become expensive as the collection grows. LogLoom instead modifies an existing program when another example arrives. In the paper's analysis, the approach scales linearly with the number of logs under assumptions about the cost of the external synthesis queries, although the search remains exponential in the complexity of the final program. The last clause is not small print. A tiny program can be learned from many logs; a complicated program remains complicated. [1]

A subtle consequence follows. An automation can grow as the organisation learns. First it handles the normal shutdown. Then it handles a failure. Later a different status response demands a retry. The program becomes a kind of compressed operational memory, revised by examples rather than rewritten from scratch.

There is something almost archival about that. The organisation's practices have been sitting in its logs all along, but the rules were scattered among thousands of events. The synthesis system tries to find the grammar of those practices.

## What the numbers actually say

The evaluation contains 72 tasks: 62 in which a script is synthesised from scratch, and ten in which an existing script is extended. The authors assembled them from prior research and automation examples, including AWS Systems Manager runbooks and Blink scripts. The reference programs are small by general software standards: up to six API calls, two conditions and two loops. Each benchmark has a human-authored reference. [1]

The headline 60/72 means LogLoom produced a program with the intended **control-flow structure** on 60 tasks: 52 of 62 from scratch and eight of ten extensions. The comparison with Syren's 14 applies to the 62 from-scratch tasks, not all 72. The authors classify another eleven LogLoom outputs as *valid*: they reproduce the observed logs but differ from the reference structure. One task timed out. In the reported experiment, it produced no invalid outputs under the benchmark's trace-consistency definition. [1]

That is an impressive result in a carefully specified research setting. It is not the same as 60 production automations deployed safely. It does not establish that every program was the best one, or that every relevant exception appeared in the recorded examples. The authors themselves show how loop-heavy cases can trap the incremental method: an early, awkward solution makes later additions harder. Changing the order of the logs can change both runtime and whether synthesis times out. [1]

The paper compares the system with several LLM baselines, including agentic configurations. Those results are useful but depend on the models, prompts, verifier access, time budgets and benchmark design used in the experiment. The story is not 'symbolic AI beats language models'. The more promising lesson is that a specialised verifier can tell us things a fluent program generator cannot safely be trusted to assert about itself.

And there is a practical limitation as of this editorial pass: the authors' paper says the LogLoom code and benchmark artifact are undergoing internal review for release. Toolglass found the paper and an author-hosted PDF, not a publicly verifiable release of the complete tool. This is **research, not a product review**. [1]

> **PULL QUOTE 02 / TOOLGLASS EDITORIAL**
> The machine can prove that its script matches the recorded journey. It cannot prove that the journey was worth repeating.
>
> *Toolglass / original editorial line, not a quotation from the researchers*

## Act III / The shadow of the worker

Once the mechanism is understood, the wider implications become more interesting and less comfortable.

Consider a small company that repeatedly fixes the same deployment problem. Its operators have acquired a ritual: inspect the service, restart one component, wait for a response, check a queue, and sometimes roll back. The ritual lives in their heads and in the event history. A system capable of extracting a candidate program could make that knowledge inspectable, reviewable and perhaps teachable to a new colleague.

That is a genuine opportunity. So is the ability to recover a workflow when its original author has left. A company may have the logs of its own operations but no surviving explanation of why the operations were performed in that order. A synthesised program can be a useful hypothesis about the missing procedure.

But an inferred procedure is not a policy. Suppose a worker once disabled an alert during an incident. A log will record the action without the judgement, authority or temporary nature of the exception. An automatic learner might turn a one-off breach of normal practice into the new normal. The system needs more than trace consistency before it can be trusted to act. It needs explicit permissions, review, safe test environments, and a way to distinguish *this happened* from *this should happen*.

There is a second, quieter risk: logs are not neutral. They are collected for reasons, often by institutions with power over the people who generate them. Turning operational traces into programs might reduce drudgery, but it might also turn tacit human work into a management asset without consent or recognition. The same record that helps a technician avoid an exhausting repetition could be used to standardise every choice the technician used to make. That is a social consequence to investigate, not a result claimed by the LogLoom paper.

The historical comparison is revealing. The old dream of programming by demonstration placed a person at the centre: show the machine what you want. The log-based version can operate after the person has left the room. That is both its power and its problem. The more invisible the act of teaching becomes, the more important it is to decide who may learn from the record and who may authorise the resulting program.

There is a good engineering response. Treat a generated automation as a **proposal with provenance**. Keep the original traces. Record which examples caused each change. Make the inferred branches visible. Test the script in a simulation or staging environment. Require a human or a separately authorised policy system to approve consequential actions. If another log later contradicts the program, preserve the disagreement rather than silently smoothing it away.

This would not make automation effortless. It would make it accountable. The purpose of a good synthesis system is not to remove every human from the loop. It is to stop wasting human attention on reconstructing mechanical steps while preserving human authority over their meaning.

## The program that nobody wrote

A conventional program begins with an instruction: do this, then this, unless that. A log begins at the other end: this happened, then this, and here is what came back.

LogLoom attempts the journey backwards. It looks at the record and asks what small, general program could have produced it. The system is imperfect, the benchmarks are bounded, the public artifact is not yet confirmed, and the leap from a matching script to a trustworthy operational tool remains large. None of those reservations spoils the idea. They explain what the idea really is.

For decades, computers have been very good at keeping the receipts and much worse at learning from them. The interesting prospect is not a machine that remembers every click. It is a machine that can turn yesterday's evidence into tomorrow's **inspectable suggestion**, while leaving enough room for a human to say: no, that is not why I did it.

That final sentence may be the most important part of the program.

### The little glossary

- **API call:** A structured request to a service, such as 'stop this instance' or 'report its status'.
- **Event log:** A time-ordered record of requests and responses. In this research, the records contain API names, inputs and outputs, not merely free-form text.
- **Control-flow graph:** A map of the paths a program can take through operations, branches and loops.
- **Program synthesis:** Constructing executable code from a specification or examples rather than writing every instruction manually.
- **SMT / Max-SMT:** Constraint-solving methods that test whether combinations of logical conditions can hold, and which conditions to change when they cannot.
- **Syren:** Earlier symbolic research system that synthesises API workflows from traces by rewriting collections of logs.

### Read More / primary and historical sources

1. **Kim, Nicolet, Dodds & D'Antoni (October 2026), *Incremental Program Synthesis from Event Logs*.** Author-hosted full paper, including method, tables and limitations: https://victornicolet.github.io/papers/oopsla26.pdf
2. **SPLASH/OOPSLA 2026 conference record**, talk delivered 5 October 2026: https://2026.splashcon.org/details/oopsla-2026/86/Incremental-Program-Synthesis-from-Event-Logs
3. **David Canfield Smith, *Pygmalion: A Creative Programming Environment* (1975)**, Stanford thesis / historical source trail: https://worrydream.com/refs/Smith_DC_1975_-_Pygmalion.pdf
4. **Allen Cypher (ed.), *Watch What I Do: Programming by Demonstration* (1993)**, historical collection: https://acypher.com/wwid/

*Source discipline: [1] is the technical primary source. The two pull quotes are original Toolglass editorial statements, not speech attributed to the researchers. No code was executed and no system was benchmarked by Toolglass.*
