---
title: Toolglass Discovery Desk / 2 November 2026
status: SCOUTING DRAFT — NOT APPROVED OR PUBLISHED
evidence_status: SPOTTED / DESK REVIEW — NOT HANDS-ON
prepared: 2 November 2026
---

# Discovery Desk / Three small revolts against the usual machine

*These are leads for Toolglass investigation, not reviews. We have read primary documentation and release material, but have not installed, benchmarked or security-audited any of the three projects. The novelty claims are assessments of design, not claims of historical firsts.*

## 01 / Toit 2.0: the tiny machine that keeps its other programs running

**Type:** Open-source language and runtime for scripts and embedded applications. **Evidence:** DESK REVIEW. **Freshness:** Toit v2.0.0 released **31 October 2026**, according to the project's release page. **Source/licence:** Toit's source repository includes LGPL 2.1 licensing; dependencies and packages may have separate terms.

The familiar microcontroller workflow is an awkward little ceremony: write a program on a large computer, build firmware, flash the device, and hope the whole apparatus survives the next change. The device often feels less like a computer you can work with than an appliance you must replace from the outside. Toit has spent years asking a more interesting question. Why should a small embedded machine not support multiple independently updatable applications?

Toit's readable, object-oriented language runs on computers and ESP32 devices. Its embedded runtime supports *containers*, but not in the fashionable sense of shipping a huge Linux image. They are independently managed applications on the same device. The project's own example is simple: keep a sensor application running while replacing another. The distinction is important. It shifts the unit of development from 'the whole firmware' toward 'one live service'. [T1]

The genuinely novel direction is not that Toit has invented multitasking, garbage collection or scripting on microcontrollers. It is the packaging of a high-level language, small runtime, separately updatable programs and practical device interfaces into one coherent embedded development experience. The historical neighbours include Forth's live systems, Smalltalk's persistent worlds and modern OTA firmware updates, but Toit chooses a different balance of constrained hardware and application independence.

**Why now:** The 31 October 2.0 release gives a timely reason to inspect a long-running design, but the final release notes themselves are modest: bug fixes, Unix-domain-socket support and firmware-configurable hostnames. Do not imply that v2.0 introduced the container model. The long alpha series includes many changes in ESP32 support and peripherals. [T2]

**Limits and investigation:** ESP32 hardware and memory constraints remain real; not every device is supported. A proper Toolglass test should use two independent applications, update one while the other is recording sensor data, then deliberately trigger an out-of-memory condition. Check recovery behaviour, RAM/flash footprint, package maintenance and exact licensing of bundled components. This is mature enough to try, not an endorsement of deployment in critical embedded systems.

**Primary sources:** [Project](https://toit.io/) · [31 Oct release notes](https://toit.io/releases/) · [Source and licence](https://github.com/toitlang/toit) · [Embedded documentation](https://docs.toit.io/)

## 02 / Unison Cloud: the distributed computer with the containers taken out

**Type:** Distributed runtime and cloud platform programmable in the Unison language. **Evidence:** DESK REVIEW. **Freshness:** Paul Chiusano announced **8 October 2026** that the formerly closed parts of Unison Cloud had been released as MIT-licensed open source. [U1]

Most cloud platforms ask the developer to package a program, send it somewhere, give it a network address, and arrange for it to speak to another program. Unison Cloud starts from a different fiction: a pool of machines should behave like a single distributed computer, and programs should be able to move work between them through a typed programming model. Its authors claim lightweight services, distributed fork/join jobs, typed communication and storage integrations. These are project claims, not Toolglass measurements.

The October announcement matters because it changes what can be inspected. The Unison Cloud client was already open. Now the Nimbus worker, the Haskell control-plane/API server and the web UI are also published. The control plane handles membership and authentication; the worker is written in Unison itself. It is an unusually complete opening of a distributed programming system, not merely a new command-line front end. [U1][U2]

The interesting idea is not 'serverless' as a marketing category. It is the attempt to make **distributed execution a language-level activity**, while keeping services small enough to avoid treating a multi-gigabyte container image as the natural unit of computation. There is a lineage here from Erlang's processes and message passing, distributed object systems and functional build/deployment models. Unison adds its own content-addressed code identity, a distinctive approach worth a separate deep reading.

**Why now:** Self-hosting the runtime is more plausible now that the worker and control plane are public. But MIT-licensed source is not the same as a polished turnkey installer. The public `cloud-api` repository documents local integration tests, a Consul-based peer-discovery path, DynamoDB/S3-oriented storage and cache-invalidation protocol details. These are useful evidence of engineering seriousness and operational complexity. [U2]

**Limits and investigation:** The documentation and tooling are specialised; the runtime is tied to Unison rather than a drop-in host for ordinary binaries. Confirm reproducible local deployment, minimum infrastructure, failure recovery, authentication boundaries and actual service size. In particular, test a worker disappearing during a distributed job. The '<200kb' service-size claim comes from the project and needs independent measurement. [U1]

**Primary sources:** [8 Oct announcement](https://www.unison-lang.org/blog/unison-cloud-open-source/) · [Cloud API source](https://github.com/unisonweb/cloud-api) · [Unison language](https://www.unison-lang.org/) · [Cloud UI](https://github.com/unisonweb/unison-cloud-ui)

## 03 / Proto: when a biological design becomes a program with constraints

**Type:** Open-source Python framework for designing DNA, RNA and protein sequences. **Evidence:** DESK REVIEW. **Freshness:** The associated research preprint is dated **22 June 2026**; the project is still developing in late 2026. This is a newly interesting research direction rather than a November launch. [P1][P2]

The idea of a programming language for biology sounds either wonderfully ambitious or faintly alarming, depending on how much time one has spent watching software eat other professions. Proto's proposal is more specific and more useful than the slogan. Instead of telling a model to 'make a protein', a researcher describes a biological construct, the regions that compose it, and the properties that candidate sequences should satisfy. Generators propose sequences, constraints score them, and optimisers repeatedly select and refine candidates.

The repository exposes seven architectural primitives, including `Sequence`, `Segment`, `Construct`, `Constraint`, `Generator`, `Optimizer` and `Program`. The companion `proto-tools` layer manages a varied set of scientific models and computational tools in isolated environments. The unusual design choice is to make the **scientific objective** the thing that is programmed, with tool selection and optimisation orchestrated behind it. The neighbouring tradition is constraint programming and scientific workflow systems, but here the objects are biological sequences and the evaluations may be expensive predictors. [P1]

**Why now:** Generative models for biological sequences are proliferating, and the hard problem is often not producing a candidate but expressing several competing requirements reproducibly. Proto attempts to put those requirements, models and search steps into one inspectable program. The preprint and public code make the idea worth studying now, even without claiming it has changed laboratory practice.

**Limits and investigation:** This is research software. The README currently describes installation from GitHub; a direct PyPI release is planned, not a current install route. Some models are gated and require separate terms or credentials; compute-intensive work may require GPUs or paid remote execution. Computational scores are **not experimental validation** of a biological design. Toolglass should test a harmless, published toy example, inspect reproducibility of the exported traces, and ask whether a reader can swap predictors without changing the intended specification. Do not claim wet-lab performance from model-generated scores. [P1][P2]

**Primary sources:** [Language source](https://github.com/evo-design/proto-language) · [Tool execution layer](https://github.com/evo-design/proto-tools) · [2026 preprint](https://www.biorxiv.org/content/10.64898/2026.06.22.733870) · [Documentation](https://proto.evodesign.org/docs/language/introduction)

---

### Editorial ordering and avoidance of duplicates

Lead the discovery section with **Toit**, because its 31 October release gives the edition a clear present-tense hook. Put **Unison Cloud** second, for its unusually concrete shift in openness and the distributed-computing model. Put **Proto** third, deliberately moving the magazine out of the terminal and into scientific programming. These are distinct from the prior issue's Sova, orangu and Mathematics Research & Evidence Atlas, and none is a duplicate of the current long-form LogLoom feature.

### Source keys

- [T1] https://toit.io/ ; https://toit.io/project/
- [T2] https://toit.io/releases/ ; https://github.com/toitlang/toit/blob/master/LICENSE
- [U1] https://www.unison-lang.org/blog/unison-cloud-open-source/
- [U2] https://github.com/unisonweb/cloud-api
- [P1] https://github.com/evo-design/proto-language ; https://github.com/evo-design/proto-tools
- [P2] https://www.biorxiv.org/content/10.64898/2026.06.22.733870
