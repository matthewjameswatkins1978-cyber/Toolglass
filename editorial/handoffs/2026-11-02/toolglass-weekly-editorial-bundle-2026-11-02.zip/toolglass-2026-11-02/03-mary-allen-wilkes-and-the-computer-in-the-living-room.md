---
title: Mary Allen Wilkes and the Computer in the Living Room
slug: mary-allen-wilkes-and-the-computer-in-the-living-room
section: People
article_type: Person profile
status: EDITORIAL DRAFT — NOT APPROVED OR PUBLISHED
evidence_status: ARCHIVAL ORAL HISTORY / INSTITUTIONAL ARCHIVE
editor: Lucy
prepared: 2 November 2026
art: art/the-living-room-machine.webp
---

# Mary Allen Wilkes and the Computer in the Living Room

## Before a computer could fit on a desk, she made one behave as if it belonged to its user. The remarkable part was not the machine in her parents' house. It was what she taught the machine to let people do.

*Toolglass / Profile draft for Matthew's editorial pass / 2 November 2026*

In 1965, a van arrived at a house in Baltimore carrying a computer.

It was not a publicity stunt. Nobody was about to unveil a product to consumers. The computer was a LINC, a machine designed for researchers who needed to work directly with their experiments rather than submit jobs to a distant computing department. The person waiting for it was Mary Allen Wilkes, a programmer who wanted to finish an operating environment without moving to St. Louis, where much of her team had relocated.

The arrangement was made with the sort of casual practicality that later historians find irresistible. Wilkes told her colleague Wesley Clark that she did not want to move. He said they would send her a LINC. Two men, as she remembered it, arrived with a van and installed it in her parents' living room. She spent much of the year writing what became **LAP6**, a remarkably capable assembly and editing environment. [1]

Her father, an Episcopal clergyman, was delighted. He told people around Baltimore that there was a computer in his living room and challenged them to say the same. The neighbours were intrigued. Wilkes, meanwhile, had work to do. [1]

It is tempting to turn this into a story about the first person with a home computer. The LINC is often called one of the earliest personal computers, and Wilkes' home installation is an extraordinary episode. But the label can distract from the achievement. A computer merely sitting in a house does not make it personal. A computer becomes personal when the person using it can inspect it, interrupt it, change it, write for it and understand what it is doing without appealing to a distant priesthood.

That was the work Wilkes had been doing for years.

> **PULL QUOTE 01 / TOOLGLASS EDITORIAL**
> The important invention was not a computer in a house. It was a computer that would answer to the person in the room.
>
> *Toolglass / original editorial line, not attributed to Wilkes*

## Act I / A girl is told what she can do

Wilkes was born in Chicago in 1937. Her family moved through Florida and eventually Baltimore, where her father led a church and her mother ran a school. In a long oral history recorded for the Computer History Museum in 2021, Wilkes recalled a household of music, theatre, books and argument. Her father held Sunday-evening reading seminars, and the teenage Wilkes was allowed to listen to discussions of T. S. Eliot and Wallace Stevens. She studied piano and loved mathematics, especially a tiny solid-geometry class that felt almost like a tutorial. [1]

There was also a useful bit of accidental career advice. A geography teacher in eighth grade told her that she ought to become a computer programmer. She had scarcely heard of computers, but the suggestion stayed with her because it was something a girl was being told she *could* do, at a time when she was hearing many things she supposedly could not. [1]

The career she actually wanted was law. She liked reasoning and the courtroom, not merely the paperwork around it. But by the end of her philosophy degree at Wellesley in 1959, the people she consulted had made the barriers painfully clear. In a note added to her oral history transcript, she described being warned that a woman would struggle to enter law school, finish, find a job or practise the kind of law she wanted. She was not looking for the job of breaking barriers; she wanted the job of being a lawyer. [1]

So she tried the other suggestion. After graduating, she visited the MIT employment office and was hired to program computers. She had not trained as a programmer. In the late 1950s that was less peculiar than it sounds: the profession was still being assembled, and philosophy, mathematics and an appetite for precise reasoning could be a better qualification than a course that did not yet exist.

She began with the large computers of the era, where the machine and the person were separated by procedures, queues and punched cards. This was computing as an institution. You prepared work, submitted it and waited. The machine's time was valuable; the user's time was often treated as a cheap and renewable resource.

Wilkes did not set out with a manifesto to overthrow that arrangement. She joined a group whose practical problem required something different.

## The machine beside the experiment

At MIT Lincoln Laboratory, Wesley Clark and Charles Molnar were working on the **Laboratory Instrument Computer**, or LINC. Biomedical researchers wanted to record signals from living systems, adjust the experiment and immediately see what changed. Waiting for a batch job was not simply inconvenient. The data might be coming from a body in real time. If the experiment had ended before the computer responded, the answer was no longer useful.

The LINC was built around that constraint. It was relatively small, with a keyboard, display, analogue-to-digital input, controls the user could turn, and compact magnetic tapes for storing programs and data. The researchers could connect instruments directly to the machine. They could sample a signal, change a knob and watch the effect. The computer was part of the laboratory bench, not a distant calculation bureau. [1][2]

Hardware is only half of such a promise. The machine also needed software that a scientist could actually use. Wilkes was asked to make it.

Her early work included a LINC simulator running on the larger TX-2 computer, so the team could prepare software before a physical LINC was ready. This was a quiet piece of engineering foresight. A machine that did not yet exist could have programs waiting for it on arrival. Then came the assembly programs, including LAP2 and LAP3, that gave users ways to enter, edit, translate and save their own instructions. [1]

Here is where the usual history of personal computing often becomes too eager to talk about hardware. The computer had a display, yes. But what appeared on the display, and what a user could *do* to it, mattered just as much.

In the early LAP versions, a scientist could type a program and see its lines on the scope. Wilkes called the collection of code a **manuscript**. It was a revealing word. A manuscript is something a person writes, revises and returns to. The computer was beginning to treat a program not as a packet to be submitted but as a document to be worked on.

The earliest editor was cramped. With only about a thousand 12-bit words of memory, Wilkes had to store changes separately and later pack them into the manuscript on tape. In a retrospective note in the oral history, she described how users could scroll through their work with a knob and see typed lines and edits appear on the display. The screen was already a graphical working surface, even if its controls and constraints looked very different from a modern editor. [1]

That is the less familiar ancestry of the desktop computer. Not a direct line from one machine to another, but a recurring design demand: let the person see the thing they are changing while they change it.

## Act II / A working language for the person at the controls

The LINC Evaluation Program sent machines into laboratories where biomedical researchers had to write their own application software. That could have been a disaster. Give a scientist a computer but make every change dependent on a specialist programmer, and you have merely moved the queue closer to the experiment.

Wilkes understood the audience. In her oral history she said that the non-specialist user was central to the LINC's design, not an afterthought. She did not write the biomedical applications for them. She helped make an environment in which they could write those applications themselves, save them, exchange them and invoke them alongside the system software. [1]

This sounds ordinary now, which is how one recognises a successful interface idea after enough decades. In the early 1960s it was radical. Most users did not own a machine, and most machines did not expect users to interact continuously. The LINC gave a scientist a relatively direct conversation with the hardware. LAP gave the conversation a grammar.

There was an awkward period when the software and hardware were growing together. The evaluation laboratories found bugs, learned the controls and asked for improvements. Some developed applications worth sharing with the other sites. Wilkes' work was shaped by that feedback. The most interesting design decisions did not come from an abstract list of fashionable features. They came from watching people use the machine for real work.

In 1964 the LINC group moved to Washington University in St. Louis. Wilkes had been travelling, including an almost year-long journey around the world, and did not want to settle in St. Louis. She returned to Baltimore and took the machine-at-home arrangement instead. [1]

Before beginning the final version, she visited roughly ten LINC laboratories to learn what was frustrating the users. One trip to Wisconsin was interrupted by a blizzard, and she ended up in Fargo, unable to contact the researcher waiting for her in Madison. It is a small detail, but it says something about the work. User research in 1965 involved boarding aeroplanes, being stranded in the weather and arriving with a notebook full of practical complaints. [1]

Then she went home and rebuilt the editing environment.

LAP6 took advantage of a LINC with approximately twice the earlier core memory, roughly two thousand words. Wilkes could finally hold more of the manuscript in memory and change it directly as the user worked. She devised a different editing algorithm around a **broken string**: imagine a long strip of text with a movable break at the place you want to edit. Move the break, insert or remove material, and let the software manage the surrounding pieces. The user saw the change where it belonged; the tape movement and storage housekeeping happened behind the scenes. [1]

It is a wonderfully concrete solution to an abstract problem. The computer's memory was far too small to keep a large manuscript available all at once. The software created the *experience* of working on a continuous document anyway. A person could move up and down, insert lines, append another manuscript and save work without manually juggling tape blocks. The machine did the juggling.

LAP6 also improved error reporting and debugging. Programmers could use labels, comments and symbolic constants, and the system could catch mistakes such as duplicated labels or missing definitions. A researcher could insert HALT instructions and step through the machine's execution using the console switches and lights. The result was not the modern integrated development environment, but it had many of the same ambitions: make the program visible, editable, testable and understandable while it is being built. [1]

Wilkes described researchers integrating their own application software into the operating environment so they could run it without repeatedly loading separate tapes. That was more than convenience. It gave each laboratory the possibility of building a local software culture and exchanging its useful inventions with the others. The platform was not finished when the hardware shipped. The users could extend it.

> **PULL QUOTE 02 / TOOLGLASS EDITORIAL**
> She spent precious memory on the thing the machine could not measure: the user's time.
>
> *Toolglass / original editorial line, not attributed to Wilkes*

## The other strange computer

There is a lesser-known side path in Wilkes' computing career that deserves more attention than it usually receives. The LINC was not her only exposure to unusual machine architecture. Her oral history discusses work on the **macromodule** project, an attempt to make computing hardware out of modular, asynchronous building blocks. Rather than designing one monolithic processor around a universal clock, the idea was to assemble functional modules into a system suited to a problem. [1]

This is a very different kind of personalisation from a keyboard and screen. It asks whether the hardware itself can be composed around the task. It belongs to the same broad experimental climate as other early modular and interactive systems, where engineers had not yet accepted that every computer had to take the shape of the eventual mass-market personal computer.

Wilkes' recollections are especially valuable because they resist the neatness of a retrospective origin myth. She sometimes corrects dates, admits she cannot remember the details of an intermediate LAP version, and distinguishes her software from the biomedical programs that other people wrote. She remembers colleagues and their contributions. The historian gets a working engineer's account, complete with uncertain memory and inconvenient detail, rather than a flawless legend assembled decades later. [1]

One of those details matters greatly. The LINC's success was collective: Clark and Molnar on hardware, Wilkes on operating software, other engineers on tape systems and electronics, researchers in the evaluation laboratories creating the applications. The interesting achievement was not a lone genius inventing the future in a living room. It was a team making a new relationship between a human and a machine possible, and a programmer who understood how much of that relationship lived in the editor.

## Act III / The career she actually wanted

The end of Wilkes' story is usually told as a twist: the pioneering computer programmer became a lawyer. But that gets the direction backwards. Law had been the original ambition. Computing was the extraordinary detour.

In 1972, Wilkes enrolled at Harvard Law School. She earned her degree and practised law for decades, including litigation and arbitration. The Washington University medical library's 2024 archival profile records that career alongside her work on the LINC, rather than treating her as though she disappeared when she stopped writing system software. [2]

The symmetry is difficult to resist, though it should not be exaggerated. A lawyer and a systems programmer both spend their days reasoning about rules, exceptions, evidence and consequences. Wilkes had enjoyed logic and argument from childhood. She did not need to stay in computing to remain the same kind of thinking person.

Nor was the move from computers to law a rejection of technical work. In her own account, she had never particularly wanted the symbolic status of a pioneer. She wanted to do the job in front of her, whether that meant constructing an editor in two thousand words of memory or arguing a case in court. [1]

There is an irony in the later honours. The world now recognises her as a computing pioneer, precisely the sort of public identity she once hoped to avoid in law. But the recognition is deserved for something more substantial than a photograph beside a large machine. Wilkes helped make a computer usable by people whose primary expertise was not computing. She gave them a way to prepare, inspect, debug, save and share their own work.

Modern computers are unimaginably more capable than the LINC. Their memory can hold entire libraries, their displays can render a world, and their networks can send a program around the planet in a moment. Yet the old problem persists. We still build systems in which the person is expected to learn the machine's private rituals. We still celebrate a new feature without asking whether it removes a burden from the user or merely moves it somewhere less visible.

Wilkes' work offers a harder standard. A good interface is not simply friendly. It makes a capable person **more capable**. It takes the constraints of the machine seriously enough that the person does not have to carry them all.

In Baltimore, a computer sat in the living room, and a clergyman boasted about it to his neighbours. The more important event was happening on its display. A programmer was teaching a machine how to make room for another person's ideas.

### The workbench / A short guide to the machines and tools

- **LINC (Laboratory Instrument Computer):** A small-for-its-era interactive laboratory computer developed by Wesley Clark's team. It could collect experimental signals, display them and respond directly to a user's controls.
- **TX-2:** A larger experimental computer at MIT Lincoln Laboratory. Wilkes used it to simulate LINC software before LINC hardware was available.
- **LAP / LAP3 / LAP6:** The LINC Assembly Program family, combining assembly, program editing and storage functions. LAP6's interactive editing was a major step beyond the earlier memory-constrained versions.
- **LINCtape:** A compact magnetic-tape storage system for LINC programs and data, designed for direct use by the researcher.
- **Core memory:** Magnetic storage used as the machine's working memory. A few thousand 12-bit words imposed severe constraints on the editor.
- **Broken string:** Wilkes' description of the LAP6 editing method: work at a movable break in a continuous manuscript, while the system manages the memory and tape transfers.
- **Macromodules:** Modular, asynchronous computing hardware research, a less-remembered strand of the experimental work around LINC's designers.

### Read More / first-person and archival sources

1. **Mary Allen Wilkes, oral history, part 1 of 2.** Interviewed by David C. Brock, Computer History Museum, 28 July 2021. This is the central first-person source, including Wilkes' own corrections and uncertainty: https://archive.computerhistory.org/resources/access/text/2024/06/102792262-05-01-acc.pdf
2. **Laura Weis, *Mary Allen Wilkes*.** Bernard Becker Medical Library, Washington University in St. Louis, 4 April 2024. An institutional archival profile with source notes and photographs: https://becker.wustl.edu/news/mary-allen-wilkes/
3. **Mary Allen Wilkes, *Conversational Access to a 2048-Word Machine* (1970).** Historical technical article, linked from the Washington University archive profile: https://www.digibarn.com/stories/linc/documents/LINC-Mary-Allen-Wilkes/Conversational-Access-CACM-1970.pdf
4. **Computer History Museum oral histories.** Collection overview and research context: https://computerhistory.org/oral-histories/

*Editorial note: Both pull quotes are original Toolglass prose, not fabricated statements by Wilkes. The first-person account is recollection recorded in 2021; approximate dates and memory gaps are retained where relevant. No historical photograph or likeness is reproduced in the original conceptual artwork.*
