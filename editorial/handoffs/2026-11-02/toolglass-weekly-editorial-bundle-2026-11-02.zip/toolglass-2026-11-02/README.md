# Toolglass weekly editorial bundle / 2 November 2026

**Review edition. Not approved. Not published.** This archive contains two long-form articles, three scouting notes, original local SVG/WebP concept plates, source audits, a production guide and an offline HTML preview. It is for Matthew's editorial review and voice pass.

## Read in this order

1. `02-the-program-was-already-in-the-log.md` — feature on LogLoom and the attempt to infer automation from structured event logs (about 2,750 words).
2. `03-mary-allen-wilkes-and-the-computer-in-the-living-room.md` — profile of a programmer who made the LINC an interactive working instrument (about 3,000 words).
3. `01-discovery-desk.md` — Toit 2.0, Unison Cloud and Proto, each with primary sources, maturity and tests worth doing.
4. `art/contact-sheet.webp` — both original Toolglass-style concept plates. SVG masters are editable.
5. `04-source-and-claim-audit.md` and `05-art-and-production-guide.md` — provenance, factual limits, captions, rebuild commands and integration requirements.
6. `preview.html` — self-contained editorial HTML except for its two local `art/*.webp` image references. Open it locally with the `art/` directory alongside.

## Editorial choice

The lead asks whether yesterday's logs can become tomorrow's program without mistaking observation for intention. The profile returns to the origins of interactive personal computing through Mary Allen Wilkes' LAP6 editor and unusual career. The scouts span embedded systems, distributed execution and biological constraint programming.

The two articles each have **exactly two** freestanding editorial pull quotes and original concept art. The profile has a compact technical sidebar and a short Read More section. No historical likenesses, AI-generated images or borrowed artwork are included.

## Source and release boundaries

The LogLoom implementation was not independently tested, and its authors' paper says the release artifact was still under internal review. Toit/Unison/Proto are desk research, not hands-on reviews. All sources are linked in the manuscripts and audit. **Matthew must approve before publication.**

## Rebuild artwork

```sh
python production/build_art.py
python production/build_preview.py
```

Artwork pipeline: svgwrite → Inkscape → Pillow, adapted from the 26 October Toolglass source. Preview layout: adapted from the 26 October editorial HTML. The previous issue's reference files are **not included** in the deliverable ZIP; the production scripts run without them.
