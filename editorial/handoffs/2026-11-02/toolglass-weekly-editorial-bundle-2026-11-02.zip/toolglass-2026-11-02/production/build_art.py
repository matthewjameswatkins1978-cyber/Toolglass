#!/usr/bin/env python3
"""Toolglass 02 Nov 2026 local concept-plate drawing workflow.

Uses svgwrite, Inkscape and Pillow, reusing the 26 Oct Toolglass plate palette,
size, registration marks, fine strokes and monochrome/cobalt/lime language.
All marks are original vector geometry. No generative image tools, stock assets,
external fonts, likenesses or archival photograph reproduction.
"""
from pathlib import Path
import random, subprocess
import svgwrite
from PIL import Image, ImageOps
ROOT=Path(__file__).resolve().parents[1]; ART=ROOT/'art'; ART.mkdir(exist_ok=True)
W,H=1536,1024
PAPER='#eee9dc'; INK='#202522'; BLUE='#1748a0'; MID='#6683b7'; GREY='#8d8e80'; LIME='#c4ef32'; WHITE='#f9f6ed'; PALE='#dce2d7'

def text(d,s,x,y,size=15,color=BLUE,spacing=1.2,anchor='start'):
 d.add(d.text(s,insert=(x,y),fill=color,font_size=size,font_family='DejaVu Sans Mono',letter_spacing=spacing,text_anchor=anchor))
def rect(d,x,y,w,h,stroke=INK,sw=1.8,fill='none'):
 d.add(d.rect(insert=(x,y),size=(w,h),fill=fill,stroke=stroke,stroke_width=sw))
def line(d,x1,y1,x2,y2,color=GREY,sw=1,dash=None):
 opts={'stroke':color,'stroke_width':sw}
 if dash:opts['stroke_dasharray']=dash
 d.add(d.line((x1,y1),(x2,y2),**opts))
def circ(d,x,y,r,fill='none',stroke=INK,sw=1.5):
 d.add(d.circle(center=(x,y),r=r,fill=fill,stroke=stroke,stroke_width=sw))
def path(d,cmd,color=BLUE,sw=1.8,dash=None):
 attrs={'fill':'none','stroke':color,'stroke_width':sw}
 if dash:attrs['stroke_dasharray']=dash
 d.add(d.path(d=cmd,**attrs))
def init(name,desc,code):
 d=svgwrite.Drawing(str(ART/name),size=(W,H),viewBox=f'0 0 {W} {H}',profile='full')
 d.add(svgwrite.base.Title('Toolglass | '+code));d.add(svgwrite.base.Desc(desc))
 d.add(d.rect(insert=(0,0),size=(W,H),fill=PAPER))
 rng=random.Random(20261102)
 for _ in range(460):d.add(d.circle(center=(rng.uniform(64,W-64),rng.uniform(60,H-60)),r=.65,fill=INK,opacity=.065))
 text(d,'TOOLGLASS / MACHINE FOLKLORE / '+code,92,81,13,BLUE,1.6)
 for x,y in [(104,122),(1432,122),(104,896),(1432,896)]:
  line(d,x-19,y,x+19,y,GREY,.8);line(d,x,y-19,x,y+19,GREY,.8)
 rect(d,100,855,20,20,BLUE,1,BLUE);rect(d,132,855,20,20,INK,1,LIME)
 text(d,'02 / XI / 2026',1320,947,12,GREY,1.4)
 return d

def log_plate():
 d=init('the-unwritten-program.svg','Three partial event logs feed a minimal conditional program. Conceptual diagram of trace-to-control-flow synthesis, not a screenshot or benchmark result.','LOGS / 03')
 text(d,'THE PROGRAM / AFTER THE FACT',123,194,23,INK,1.8)
 text(d,'TRACES / CONDITIONS / A MISSING BRANCH',123,225,13,BLUE,1.3)
 # input paper ledger
 rect(d,122,287,442,460,INK,2)
 text(d,'EVENT ARCHIVE',149,322,17,BLUE,1.5)
 for i in range(3):
  y=355+i*119
  rect(d,147,y,391,103,GREY,1.1,WHITE)
  text(d,f'TRACE 0{i+1}',163,y+25,13,BLUE,1.3)
  # short event bars
  for j in range(3 if i==1 else 2):
   xx=163+j*109
   rect(d,xx,y+45,91,16,INK,1,BLUE if j==0 else (LIME if i==1 and j==2 else WHITE))
   line(d,xx,y+73,xx+78,y+73,GREY,.8)
  if i==1:
   circ(d,503,y+80,6,LIME,INK,1)
  else:
   circ(d,503,y+80,4,WHITE,GREY,1)
 # wire into a constrained-search mechanism
 path(d,'M 564 516 C 607 516 609 516 652 516',BLUE,2)
 for x in [583,605,627]:circ(d,x,516,3,LIME,INK,.8)
 rect(d,652,365,241,307,INK,2,WHITE)
 text(d,'MATCH / EDIT',672,398,15,BLUE,1.1)
 for i in range(5):
  y=430+i*43
  rect(d,680,y,185,26,GREY,.8,'none')
  line(d,689,y+13,856-(i%3)*22,y+13,BLUE,1.1,'4,5')
 circ(d,771,628,11,LIME,INK,1.5)
 # decision tree right
 path(d,'M 893 516 C 936 516 932 516 973 516',BLUE,2)
 rect(d,975,287,441,460,INK,2)
 text(d,'CANDIDATE PROGRAM',999,322,17,BLUE,1.5)
 rect(d,1108,359,174,48,INK,1.7,WHITE);text(d,'STOP',1195,389,15,BLUE,1.2,'middle')
 line(d,1195,407,1195,440,BLUE,2)
 rect(d,1090,440,210,48,INK,1.7,WHITE);text(d,'CHECK STATUS',1195,470,15,BLUE,1.1,'middle')
 line(d,1195,488,1195,524,BLUE,2)
 # diamond decision
 path(d,'M1195 523 L1290 588 L1195 653 L1100 588 Z',INK,2)
 text(d,'STOPPED?',1195,591,14,BLUE,.8,'middle')
 # conditional branch right to exit
 path(d,'M1290 588 L1373 588 L1373 683',BLUE,2)
 text(d,'YES',1315,577,12,GREY,.8)
 circ(d,1373,683,7,WHITE,INK,1.4)
 # no branch to force
 path(d,'M1100 588 L1015 588 L1015 681 L1135 681',BLUE,2)
 text(d,'NO',1040,577,12,BLUE,.8)
 rect(d,1135,661,172,42,INK,1.5,LIME)
 text(d,'FORCE STOP',1221,687,13,INK,.7,'middle')
 path(d,'M1307 682 L1373 682',BLUE,2)
 # bottom
 line(d,122,786,1416,786,INK,1.2)
 text(d,'OBSERVED ACTIONS',122,822,14,BLUE,1.3)
 text(d,'DO NOT CONTAIN',506,822,14,INK,1.3)
 text(d,'THE RULES BETWEEN THEM',773,822,14,BLUE,1.3)
 text(d,'FIG. 03 / CONCEPTUAL CONTROL FLOW; NOT AN EXECUTABLE SCRIPT',219,874,10,GREY,1)
 d.save()

def linc_plate():
 d=init('the-living-room-machine.svg','An anonymous programmer is placed inside the working system of a LINC, tape transport and editable manuscript, with domestic details at the edge. Not a likeness of Mary Allen Wilkes or a reconstruction of the historical room.','LINC / 04')
 text(d,'A COMPUTER / AT HUMAN SCALE',123,194,23,INK,1.8)
 text(d,'THE EDITOR BETWEEN MACHINE AND PERSON',123,225,13,BLUE,1.3)
 # domestic outline / window and table, deliberately not a room reconstruction
 rect(d,119,295,362,449,INK,2)
 text(d,'ROOM / 1965',143,328,15,BLUE,1.2)
 rect(d,150,358,137,157,GREY,1.3,WHITE)
 line(d,218,358,218,515,GREY,1.2);line(d,150,438,287,438,GREY,1.2)
 for x,y in [(171,386),(193,404),(238,389),(263,418)]:circ(d,x,y,2.3,LIME,INK,.4)
 # table and tiny domestic objects
 line(d,147,603,450,603,INK,2);line(d,167,603,167,710,INK,2);line(d,427,603,427,710,INK,2)
 rect(d,307,540,115,61,INK,1.6,WHITE)
 rect(d,321,550,87,38,BLUE,1.1,PALE)
 for i in range(4):line(d,332,560+i*8,395-i*4,560+i*8,BLUE,.8)
 # a small anonymous working figure inside system
 circ(d,260,555,23,WHITE,INK,1.8)
 path(d,'M237 582 Q258 568 280 585 L300 604 L218 604 Z',INK,1.8)
 line(d,281,588,321,589,INK,1.7)
 rect(d,350,713,52,8,INK,.8,WHITE)
 # central LINC-inspired conceptual machine, no literal hardware claim
 rect(d,517,294,517,452,INK,2)
 text(d,'INTERACTIVE MACHINE',545,328,15,BLUE,1.3)
 rect(d,547,366,276,249,INK,2,WHITE)
 rect(d,566,385,238,198,BLUE,1.2,PALE)
 # six-line program manuscript on scope
 for i in range(8):
  y=409+i*20
  text(d,f'{i+1:02d}',579,y,10,GREY,.3)
  line(d,609,y-4,778-(i%3)*26,y-4,BLUE,1.1)
 rect(d,606,482,148,19,INK,.9,LIME)
 line(d,608,500,775,500,BLUE,.7,'3,5')
 # keyboard and tape spools
 rect(d,550,637,279,51,INK,1.6,WHITE)
 for j in range(3):
  for i in range(13):rect(d,561+i*19,646+j*11,13,6,GREY,.6,WHITE)
 rect(d,855,377,145,267,INK,1.6,WHITE)
 for cy in [439,551]:
  circ(d,928,cy,42,WHITE,INK,2)
  circ(d,928,cy,12,WHITE,INK,1.4)
  for i in range(8):
   import math
   a=i*math.pi/4
   line(d,928+17*math.cos(a),cy+17*math.sin(a),928+35*math.cos(a),cy+35*math.sin(a),GREY,.8)
 line(d,928,481,928,510,BLUE,2)
 text(d,'TAPE',929,619,12,BLUE,1.2,'middle')
 # manuscript right side and connecting cables
 path(d,'M1034 508 C1073 508 1069 508 1106 508',BLUE,2)
 rect(d,1107,295,307,450,INK,2)
 text(d,'MANUSCRIPT',1133,329,15,BLUE,1.3)
 rect(d,1135,361,248,308,INK,1.6,WHITE)
 for j in range(13):
  y=382+j*20
  line(d,1153,y,1358-(j%4)*26,y,GREY,.9)
 # broken string cursor as conceptual break
 rect(d,1150,501,212,40,INK,1,LIME)
 line(d,1256,492,1256,550,BLUE,2)
 circ(d,1256,501,6,WHITE,INK,1)
 text(d,'EDIT HERE',1256,526,13,INK,1.0,'middle')
 # link human, machine and manuscript
 path(d,'M481 530 C495 530 501 530 517 530',BLUE,2)
 circ(d,481,530,6,LIME,INK,1)
 circ(d,517,530,6,LIME,INK,1)
 # lower slogan
 line(d,119,789,1416,789,INK,1.2)
 text(d,'THE MACHINE HANDLES THE TAPE.',200,835,16,INK,1.1)
 text(d,'THE PERSON HANDLES THE IDEA.',200,867,14,BLUE,1.2)
 text(d,'FIG. 04 / CONCEPTUAL; NO LIKENESS OR ARCHIVAL ROOM RECONSTRUCTION',745,926,10,GREY,1.1)
 d.save()

def export():
 for stem in ['the-unwritten-program','the-living-room-machine']:
  src=ART/(stem+'.svg');png=ART/(stem+'.png')
  subprocess.run(['inkscape',str(src),'--export-type=png','--export-filename='+str(png),'--export-width=1536'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  with Image.open(png) as im:im.convert('RGB').save(ART/(stem+'.webp'),'WEBP',quality=91,method=6)
  png.unlink()
 sheet=Image.new('RGB',(1280,1740),'#e6e2d6')
 for i,stem in enumerate(['the-unwritten-program','the-living-room-machine']):
  with Image.open(ART/(stem+'.webp')) as im:
   im.thumbnail((1130,755));sheet.paste(im,((1280-im.width)//2,52+i*845))
 sheet.save(ART/'contact-sheet.webp','WEBP',quality=91,method=6)

if __name__=='__main__':
 log_plate();linc_plate();export();print('Created 2 SVG masters, 2 WebP renders and contact sheet')
