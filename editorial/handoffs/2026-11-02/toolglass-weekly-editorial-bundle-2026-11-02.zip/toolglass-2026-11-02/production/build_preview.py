#!/usr/bin/env python3
"""Build a local, offline, unpublished Toolglass editorial preview.
Reuses the 26 October preview CSS as an editorial layout reference.
"""
from pathlib import Path
import html,re
import mistune
R=Path(__file__).resolve().parents[1]
reference=(R/'_reference/toolglass-2026-10-26/preview.html').read_text()
css=re.search(r'<style>(.*?)</style>',reference,re.S).group(1)
css += '''
.article figure.pullquote{max-width:1000px;margin:75px auto 80px;padding:22px 0 16px;border-top:1px solid var(--ink);border-bottom:1px solid var(--ink);background:transparent;color:var(--blue)}
.article figure.pullquote blockquote{margin:0;padding:0;border:0;max-width:100%;font:normal clamp(34px,4.4vw,63px)/1.13 Georgia,serif;letter-spacing:-.035em}
.article figure.pullquote figcaption{font:11px/1.5 monospace;letter-spacing:.08em;text-align:right;color:#686c64;margin-top:18px}
.article figure.pullquote .label{font:11px/1.4 monospace;letter-spacing:.09em;color:var(--blue);margin-bottom:18px}
.article .dek{font:normal 28px/1.34 Georgia,serif;color:#4e534d;max-width:850px;margin:0 0 30px}
.article .meta{font:11px/1.4 monospace;letter-spacing:.07em;color:#6a6e68;margin-bottom:35px}
.article .plate{max-width:1160px;margin:40px auto 60px}
.article>h2:first-of-type{font:normal 38px/1.13 Georgia,serif;max-width:820px;margin:0 auto 28px;color:#4e534d}
.article .prose-body{max-width:750px;margin:auto}
.article li,.article a{overflow-wrap:anywhere;word-break:normal}
@media(max-width:720px){.article figure.pullquote blockquote{font-size:36px}.article .plate{margin:28px -6px 40px}.article>h2:first-of-type{font-size:27px}}
'''
md=mistune.create_markdown(escape=False,plugins=['strikethrough','table'])

def convert(path,art,caption,alt):
 s=path.read_text()
 s=re.sub(r'^---\n.*?\n---\n','',s,flags=re.S)
 s=re.sub(r'(?m)^\*Toolglass / (?:Feature|Profile) draft.*?\*\n','',s)
 # Standfirst remains h2, metadata inserted separately.
 def pull(m):
  label,quote,attr=m.group(1),m.group(2),m.group(3)
  return f'<figure class="pullquote"><div class="label">{html.escape(label)}</div><blockquote>{html.escape(quote)}</blockquote><figcaption>{html.escape(attr)}</figcaption></figure>\n\n'
 s=re.sub(r'> \*\*(PULL QUOTE \d+ / TOOLGLASS EDITORIAL)\*\*\n> (.*?)\n>\n> \*(.*?)\*\n',pull,s)
 rendered=md(s)
 # Insert hero plate after the standfirst, before the article's opening scene.
 plate=f'<figure class="plate"><img src="{art}" alt="{html.escape(alt)}" loading="lazy"><figcaption>TOOLGLASS / ORIGINAL CONCEPT PLATE <span>{html.escape(caption)}</span></figcaption></figure>'
 pos=rendered.find('</h2>') + len('</h2>')
 rendered=rendered[:pos]+plate+rendered[pos:]
 return rendered

feature=convert(R/'02-the-program-was-already-in-the-log.md','art/the-unwritten-program.webp','A record of actions can constrain a candidate program; the rules between them remain inferred. Not executable code.','Concept plate: three event traces pass through a matching and editing mechanism to a small control-flow diagram with status check and conditional forced stop.')
profile=convert(R/'03-mary-allen-wilkes-and-the-computer-in-the-living-room.md','art/the-living-room-machine.webp','A human-scale machine and an editable manuscript; no likeness or historical room reconstruction.','Concept plate: anonymous programmer at a domestic desk linked to a schematic LINC-inspired screen, tape reels and editable manuscript with a highlighted insertion point.')
scouts=md(re.sub(r'^---\n.*?\n---\n','',(R/'01-discovery-desk.md').read_text(),flags=re.S))
page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Toolglass / 2 November 2026 / Editorial preview</title><style>{css}</style></head><body>
<header class="top"><div class="topline"><span>AN INDEPENDENT SOFTWARE PUBLICATION</span><span>EDITORIAL PREVIEW / UNPUBLISHED</span></div><div class="mast">TOOLGLASS<span style="color:var(--lime)">.</span></div><div class="issue"><span>ISSUE DESK / 02 NOVEMBER 2026</span><nav><a href="#feature">FEATURE</a><a href="#profile">PERSON</a><a href="#desk">DISCOVERY DESK</a></nav></div></header>
<div class="intro"><h2>The machine remembers.<br>The person decides.</h2><div><p class="issue-tag">ONE RESEARCH THREAD / ONE WORKING LIFE / THREE NEW PROGRAMS</p><p>Programs inferred from the traces of work. An early computer that gave scientists a way to edit their own code. And three current projects questioning what counts as a program.</p><p><strong>For Matthew's editorial review. Not published, not tested, not approved.</strong></p></div></div>
<article class="article" id="feature">{feature}</article>
<article class="article" id="profile">{profile}</article>
<article class="article discoveries" id="desk">{scouts}</article>
<footer class="foot">TOOLGLASS / DRAFTS, ORIGINAL LOCAL SVG ARTWORK / 02 NOV 2026<br>Research and concept plates assembled for Matthew's editorial pass. No publication or deployment is implied.</footer>
</body></html>'''
(R/'preview.html').write_text(page)
print('Wrote preview.html',len(page),'bytes')
