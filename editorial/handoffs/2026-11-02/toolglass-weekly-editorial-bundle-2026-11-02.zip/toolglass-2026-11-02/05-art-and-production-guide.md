# Toolglass / 2 November 2026 / Artwork and production guide

## Artwork lineage

The 26 October Toolglass editorial bundle was opened and inspected, including `production/build_art.py`, `production/EDITORIAL-AND-ART-DIRECTION.md`, both SVG masters, WebP renders and contact sheet. The source-inspected Toolglass repository uses freestanding large pull quotes, magazine article templates, semantic evidence labels and original vector concept plates. This edition uses the same **local svgwrite → Inkscape → Pillow** pipeline, 1536×1024 canvas, paper `#eee9dc`, ink `#202522`, cobalt `#1748a0`, lime `#c4ef32`, registration crosses and sparse technical lettering. No image generation.

### Feature plate / `art/the-unwritten-program.svg`

Three abstract event traces are fed through a narrow matching/editing machine into a candidate control-flow diagram. The missing conditional branch is the editorial subject. This is **not** a screenshot of LogLoom, a reproduction of the paper's figure, or a guaranteed-correct executable program. Avoid adding API-specific labels that might suggest the diagram is the authors' exact output.

- Caption: *From recorded calls to a proposed branch. Concept plate; not executable code or a reproduction of the research system.*
- Alt text: *Three rows of recorded events pass through a matching and editing mechanism to a small decision graph with a status check and a conditional forced stop.*
- Export: `art/the-unwritten-program.webp`, 1536×1024.

### Profile plate / `art/the-living-room-machine.svg`

A tiny anonymous operator in a domestic setting connects to an interactive machine, tape reels and a manuscript with an editable break. This puts the human **inside the computing system**, rather than inventing a likeness of Wilkes or posing her beside a heroic machine. It is a symbolic object, not a historically accurate LINC chassis, room plan or tape transport.

- Caption: *The machine handles the tape; the person handles the idea. Concept plate; not a likeness or archival reconstruction.*
- Alt text: *Anonymous person at a small domestic desk linked to a schematic early computer with a screen and twin tape reels, then to a manuscript showing an insertion point.*
- Export: `art/the-living-room-machine.webp`, 1536×1024.

## Rebuild

From the edition directory, with `svgwrite`, `Pillow` and `inkscape` available:

```sh
python production/build_art.py
python production/build_preview.py
```

The SVG masters are editable in Inkscape. The scripts do not fetch external images or fonts. The WebPs are delivery assets, and `art/contact-sheet.webp` is a convenient overview. The `preview.html` file is **unpublished local HTML**, using the previous Toolglass editorial preview CSS as a starting point, not a replacement for the live Next.js layout.

## Layout requirements for Work Lucy

- Keep exactly **two** freestanding, large pull quotes in the feature and exactly **two** in the profile. Each is original editorial copy, clearly marked. No decorative giant quote marks, no filled cards.
- Preserve readable article width, generous whitespace, figure captions, responsive images, source links, the technical glossary and the profile's workbench sidebar.
- Do not convert the three desk notes into tested reviews. Use `SPOTTED` or `DESK REVIEW` evidence labels.
- This is a **review packet**, not an approved publishing packet. Do not merge into the live site or change public feeds/sitemap without Matthew's editorial approval.

## Work Lucy handoff

Inspect the current live site and the actual article/quote CSS before integrating. Read the full manuscript and source audit, not only the summary. Make any necessary factual and copy edits with explicit provenance. Preserve authored art and long-form writing. Once Matthew approves, use the existing site architecture, run repository lint/typecheck/build/radar validation, check 390px and desktop widths and actual public URLs. Report commit/deployment receipts only after a real release.
