# TOOLGLASS / 26 OCTOBER 2026

**Unpublished editorial review bundle**

---

# Three Programs That Deserve a Closer Look

**26 October 2026 | Toolglass / Discovery desk**

Not every interesting program needs to be a finished product. Some are interesting because they are trying to answer a question that most software never bothers to ask. This week: a sequencer that speaks four languages, an AI coding stack that wants to own its entire machinery, and a map that refuses to mistake a mathematical claim for mathematical knowledge.

These are **desk-researched scouting notes**, not hands-on reviews. Project descriptions are attributed to their maintainers, and any untested claim is marked accordingly.

---

## 01 / Sova: Four Languages, One Musical Clock

**Status:** DESK REVIEW / NOT TESTED  
**Category:** Live coding, music systems, language design  
**Project:** [Sova source repository](https://github.com/sova-org/Sova) · [Sova project site](https://sova.livecoding.fr/)  
**Licence:** AGPL-3.0  
**Maturity:** Active alpha, per maintainers' README checked 26 October 2026

Live coding usually begins with a language and asks what music can be made with it. Sova has a slightly different idea. What if the musical clock and sequencing engine came first, and several different programming languages could describe what should happen on it?

The project, developed by Raphaël Forment, Loïg Jezequel and Tanguy Dubois in a research/creation setting associated with Athénor CNCM and the University of Nantes's LS2N laboratory, is a Rust-based sequencer built around a virtual machine. Its four included languages have different temperaments: **Bob** is imperative, **BaLi** is Lisp-like, **Boinx** deals in pattern streams, and **Cagire** is stack-based. They share the same VM and I/O rather than each demanding a separate audio universe. [1]

That is a richer proposition than a collection of syntax themes. A pattern language can make repetition feel natural. An imperative language can make state changes explicit. A stack language can turn composition into the manipulation of small operations. If all of them address the same timeline, the composer can move between ways of thinking without moving between clocks.

Sova's README describes a two-thread timing design: a scheduler looks ahead by roughly 30 milliseconds, while a real-time-priority thread dispatches events. It supports Ableton Link for tempo synchronisation, MIDI and OSC, a built-in Doux audio engine, a shader editor, and networked collaborative sessions. The arrangement of *Lines* and *Frames* supplies the sequencer's structural vocabulary. These are upstream architectural descriptions, not measurements made by Toolglass. [1]

**Why now?** The live-coding family tree runs through languages and communities such as SuperCollider, TidalCycles and Strudel. Sova's contribution is to treat language plurality as a first-class feature of the instrument. That is worth watching in a world where creative software is too often either a fixed GUI or a single language with an audio engine bolted underneath.

**The catch:** The project explicitly calls itself alpha. Four languages, collaborative editing, audio, MIDI, OSC and graphics are a large surface to keep coherent. The README's timing claims have not been independently checked here. Nor have we assessed stability, Windows audio devices or actual musical usability.

**The Toolglass test:** Run the desktop client with one built-in demo; compose the same short eight-bar idea in two languages; confirm both address the same transport; measure MIDI-event jitter under CPU load; join a second client; then break the connection and observe how gracefully the session recovers. A good instrument should survive the musician's hands, not only the developer's examples.

**Primary sources:** [1. Repository README, architecture and alpha statement](https://github.com/sova-org/Sova); [2. Project site](https://sova.livecoding.fr/). No performance test or installation was conducted for this note.

---

## 02 / orangu: The Coding Assistant That Wants to Build Its Own Brain

**Status:** DESK REVIEW / NOT TESTED  
**Category:** Local AI, coding environments, model tooling  
**Project:** [orangu repository](https://github.com/mnemosyne-systems/orangu) · [1.3.0 release announcement](https://www.mnemosyne-systems.ai/news/2026-09-09-orangu-1.3.0/)  
**Licence:** GPL-3.0 (repository licence)  
**Maturity:** Actively developed; release 1.3.0 announced 9 September 2026

Most AI coding tools sit on top of a model server. Most model servers sit on top of another inference library. Training a model generally requires yet another stack. There is nothing inherently wrong with this. The boundaries allow good components to be reused. But every boundary is also another place where assumptions, dependencies and formats accumulate.

**orangu** is an attempt to own the whole chain in Rust. The project describes a terminal coding environment, a coordinator that starts and stops local models, and a native GGUF inference server. Its September 1.3 release added a particularly unusual component, `orangu-gguf`: a tool that can assemble a corpus, train a tokenizer, pretrain a small transformer from random weights and write a GGUF model file that the project's own server can load. [1][2]

The release announcement says a manifest describes the corpus, model size, schedule, context and weight format. It also claims deterministic output from the same seed and manifest across different CPU-core counts. That last detail is an interesting engineering promise and an excellent candidate for a reproducibility test. It is not something Toolglass has verified. [2]

The distinction between **building a model** and **building a useful model** is crucial. A small 'smoke' training run can demonstrate that tokenisation, training, file output and inference connect correctly. It cannot, by itself, establish that the result is a competitive coding assistant. The project's own documentation frames the small run as a pipeline check, not as a substitute for a major training effort.

There is a nice historical echo here. Early personal-computer magazines printed enough code that a reader could make the machine do something new rather than merely buy a product. orangu's appeal is similar: it wants to expose more of the model-making apparatus to the person operating it. Whether one integrated stack is better than a set of mature specialised libraries remains an open question.

**The catch:** The repository makes wide claims about supported model families, acceleration backends, offline privacy and zero telemetry. Those are upstream claims. A code review, network inspection and independent performance comparison would be needed before Toolglass could endorse them. The installation instructions include downloading scripts; they should be inspected before execution. The code is GPL-3.0, which matters for downstream reuse.

**The Toolglass test:** Build from a pinned source revision on a modest machine. Run the smallest documented training manifest twice with identical seeds and compare hashes. Load the result with `orangu-server`, record peak memory and elapsed time, inspect any network access during a supposedly offline session, and compare one standard GGUF model's outputs with a known reference engine. A result that passes would establish a coherent toolchain, not model quality parity.

**Primary sources:** [1. Repository README, licence and documentation](https://github.com/mnemosyne-systems/orangu); [2. Maintainer's 9 September 2026 release note](https://www.mnemosyne-systems.ai/news/2026-09-09-orangu-1.3.0/). No binary, benchmark, privacy audit or training run was performed for this note.

---

## 03 / Mathematics Research & Evidence Atlas: A Map of Claims, Not a Map of Truth

**Status:** DESK REVIEW / SITE AND SOURCE INSPECTED, NO CODE EXECUTION  
**Category:** Research navigation, evidence design, interactive visualisation  
**Project:** [Live evidence atlas](https://chrisdhayes.github.io/openai-math-atlas/) · [Source repository](https://github.com/ChrisDHayes/openai-math-atlas)  
**Licence:** Not confirmed from a licence file in the inspected repository; do not assume the website code is freely reusable  
**Maturity:** Experimental, with live-site version 4 observed 26 October 2026; repository README also describes a version 5 iteration

On 6 October, OpenAI published a very large collection of AI-generated mathematical manuscripts. The original release comprised 722 papers in 372 result families. Three manuscripts were subsequently withdrawn after a sign error, leaving 719 in the current public catalogue. The collection contains some Lean formalisation material, but a manuscript, a machine-checked statement and a result accepted by mathematicians are not interchangeable things. [1][2]

Christopher Hayes's **Mathematics Research & Evidence Atlas** tries to give this uncomfortable distinction a visual form. The site maps seventeen fields, 372 families and the manuscript records, with a way to explore source claims, formalisation links and questions still requiring independent assessment. It does not purport to prove the papers correct. In fact, its best design decision may be the refusal to turn a verification *status* into a confidence-coloured celebration. [3]

This is a tool about epistemology disguised as an interface. One branch means a paper exists. Another mark means there is a source-index link to a Lean file. Neither necessarily means the Lean statement matches the natural-language claim, that a theorem is novel, or that an expert has reproduced and understood it. The atlas's staged model runs from generation through formal evidence and independent scrutiny to shared knowledge. Those stages are deliberately different. [3]

The live site observed during research displayed a fallback warning: its browser had not loaded the source `CONTENTS.md`, so the full manuscript-level view was unavailable until the source was imported or retrieval retried. That is an important limitation, but also a decent example of honest interface design. A map that cannot load its data should say so rather than inventing a convincing constellation.

**Why now?** AI systems can generate candidate research faster than the surrounding community can check, interpret and absorb it. A useful interface for this new world might not be the one that makes the claims look most impressive. It may be the one that preserves provenance, dependencies, corrections and uncertainty.

**The catch:** This is a small independent project. Its README and live site differ in version wording, and its dynamic catalogue loading depends on access to upstream files. We have not run the repository locally, verified its parsing logic or checked every paper mapping. The atlas is not affiliated with OpenAI, and neither the atlas nor Toolglass certifies the mathematical claims. OpenAI's 719-paper count and formalisation statistics are source-reported, not an independent correctness audit.

**The Toolglass test:** Import a pinned copy of the upstream catalogue and formalisation YAML, choose ten random papers, follow each to its PDF, compare the displayed claim and status to the source, then deliberately remove the catalogue to see whether the interface degrades honestly. That would be an interface and provenance test, not a mathematical peer review.

**Primary sources:** [1. Original mathematics repository](https://github.com/openai/math); [2. Original October 2026 repository revision history](https://github.com/openai/math/commits); [3. Hayes's live atlas](https://chrisdhayes.github.io/openai-math-atlas/); [4. Atlas source](https://github.com/ChrisDHayes/openai-math-atlas). The live site was inspected as published; no local code execution or proof checking was performed.

---

### Discovery desk / editorial verdict

**Sova** is the most immediately appealing candidate for a hands-on creative-software review. **orangu** is the most ambitious engineering claim, and therefore the one most in need of bounded, reproducible testing. **The Evidence Atlas** is the most timely interface idea: a design built around the difference between producing an answer and knowing whether it deserves to be believed.

None should be promoted to **HANDS-ON** or **TESTED** on the strength of this issue alone.

---

# The Smaller Square That Wasn't

## A chipmaker spent twenty years studying a more compact memory cell. Then it decided the square was not the problem. A story about capacitors, manufacturing, and the dangerous elegance of an equation.

**By Toolglass | 26 October 2026 | Feature / memory architecture**

The most interesting thing in a technology roadmap is not always the invention. Sometimes it is the invention with a line through it.

On 21 October 2026, Micron presented its plans for the future of computer memory. There were familiar promises of greater density, new manufacturing processes and ever more intimate arrangements between memory and processors. But tucked into the discussion was a refusal. Micron would continue developing its established 6F² DRAM cells and investigate three-dimensional DRAM. It would **not** pursue 4F² as its next production architecture, citing extra complexity and cost. The company had studied the smaller cell for roughly two decades. [1][2]

To someone who has never had to persuade billions of microscopic capacitors to behave, this sounds peculiar. The names are little bits of geometry. A 4F² cell occupies, in the idealised layout, four squares of a minimum feature dimension; a 6F² cell occupies six. Four is smaller than six. That is not a controversial proposition. If memory is sold by the bit, why wouldn't a chipmaker choose the smaller square?

Because a memory cell is not a drawing of a transistor. It is a physical promise that a vanishingly small electrical charge can survive long enough to be read correctly, be refreshed, and be manufactured again and again across an entire wafer. The transistor's footprint is only one clause in that promise.

This is a story about the distance between mathematical area and useful memory. It also happens to be a useful antidote to the way technology news often treats a research result as an inevitable product roadmap.

## The leaky bucket that replaced the iron doughnut

Before there was a race to shrink capacitors, computer memory could look rather like a miniature weaving project. Magnetic-core memory stored bits in tiny ferrite rings threaded by wires. A computer with enough memory needed a great many rings, and each one took space, materials and careful assembly. The technique was ingenious and increasingly difficult to scale.

In the mid-1960s, IBM engineer Robert Dennard was working on semiconductor alternatives. His team's approach used six transistors to store one bit. Dennard's insight, conceived in 1966 and patented in 1968, was to store information as charge on a capacitor, with a transistor acting as the gate through which the charge could be written or read. The capacitor leaks. It must periodically be replenished. This is why the memory is called *dynamic*. [3]

A DRAM bit is not a tiny permanent inscription. It is a tiny electrical state kept alive by maintenance.

The first commercially consequential DRAM chips were not simply Dennard's patent manufactured verbatim. Intel's 1103, introduced in October 1970, used a three-transistor design, and its early manufacturing yields were difficult. Yet the 1-kilobit 1103 helped establish semiconductor memory as a practical alternative to magnetic core. Intel says it was the world's best-selling semiconductor device by the end of 1971. [4]

That distinction matters. A brilliant cell principle is one thing; a chip that a factory can reliably produce and a customer can buy is another. The argument has not changed much in fifty-six years.

In a modern conventional DRAM array, a bit is generally described by the one-transistor, one-capacitor shorthand, **1T1C**. Word lines select rows. Bit lines carry tiny electrical differences to sense amplifiers. A read can disturb the stored charge, so sensing and restoring are part of the choreography. Refresh happens repeatedly because physics is under no obligation to remember a number for us.

The arrangement has become staggeringly compact. Micron's October presentation says its bits per DRAM wafer have increased more than 400-fold between 1995 and 2026. That is a company-reported figure, but the historical direction is not in doubt. The machine that once needed racks of magnetic rings now keeps billions of volatile bits in chips that can fit in a hand. [2]

## Four squares, six squares, and one missing question

The letter **F** in 4F² or 6F² is a layout yardstick: a minimum lithographic feature dimension for the technology under discussion. The superscript tells us we are talking about area. If the same F is used, the nominal cell areas are 4F² and 6F². The first is one-third smaller than the second.

It is tempting to turn that directly into a density headline: one-third less area, therefore half again as many bits. In an ideal tiled array with no other constraints, that is the arithmetic. But real DRAM is not a sheet of empty squares. It is a three-dimensional electrical and manufacturing system with contacts, isolation, peripheral circuitry, error margins, heat and a component that refuses to vanish: the capacitor.

A capacitor must store enough charge to be distinguished from noise when it is read. As cells shrink, engineers can make capacitors taller, narrower, deeper, or more elaborate. They can change materials and the arrangement of electrodes. Every solution has trade-offs in leakage, coupling, mechanical stability, process steps and yield. What matters is not simply how little silicon a transistor claims on paper, but how closely the entire working cell can be packed without losing the electrical signal or the ability to manufacture it economically.

Imagine designing a car park where the painted parking bays become one-third narrower. Your plan shows a marvellous gain in capacity. Then the cars arrive. Their doors, turning circles and safe clearances have not shrunk by the same amount. You have not discovered a new car park; you have discovered a disagreement between a diagram and a vehicle.

For DRAM, the capacitor pitch is one of those inconvenient clearances. Micron's argument is that this pitch, rather than the attractive number attached to the transistor-cell layout, governs practical bit density at the advanced nodes it is targeting. The company's leadership also points to the complexity and cost of making 4F² work. [1][5]

> **A smaller transistor footprint is not automatically a smaller working memory cell.**
>
> *TOOLGLASS / EDITORIAL EXTRACT 01*

This is not a claim that 4F² cannot be built. In fact, the distinction between *possible* and *worth manufacturing* is the centre of the story.

## The alternative is not imaginary

At the 2025 Symposium on VLSI Technology and Circuits, researchers reported integration of a 4F² DRAM array using a vertical-gate cell transistor and a peri-under-cell architecture. The paper describes wafer bonding and electrical connections between a cell wafer and a peripheral-circuit wafer. It is a real technical demonstration, published in the IEEE record, not merely a pretty road-map rectangle. [6]

That work does not prove that the design will beat 6F² on the measures that decide a commercial memory product: good bits per wafer, cost, yield, speed, retention, power, and the ease of scaling the next generation. Nor does Micron's decision prove that the rival architecture is a dead end for everybody. Other manufacturers may choose different structures, processes, customer needs or economic assumptions. An integration demonstration, a pilot production line and a mass-market memory chip are three different achievements.

This is why we should be suspicious of the phrase *the industry has decided*. One company has made a consequential choice and explained its reasoning. Competitors are still exploring other choices. The experiment is not over; the cost of running it is simply enormous.

There is another complication. The label 4F² can refer to a particular cell footprint without uniquely specifying every detail of the vertical transistor, storage capacitor, contact geometry and peripheral circuits. Two chips with the same nominal cell-area notation can behave very differently in fabrication. The shorthand is useful, but it is not the entire circuit diagram.

## The October decision

Micron's 21 October technology presentation places the decision on a slide about continuous DRAM scaling. The message is unusually direct: the company is extending 6F² and developing 3D DRAM, and is not pursuing 4F² because of increased complexity and cost. [2]

The same presentation sketches a sequence of future processes. Its 1γ generation is already in high-volume manufacture; 1δ is planned to ramp in the second half of 2027 and is expected, by Micron, to improve bit density by a percentage in the mid-twenties over the preceding generation. Later nodes include more development and pathfinding work. Those are road-map targets, not a record of future chips already delivered. [2]

The company also talks about new ways of bonding wafers, using advanced lithography and materials, and arranging memory closer to computation. These are not all the same technical trick. Some make cells smaller in the plane. Some change how memory and logic are packaged. Some point towards stacking cells in the third dimension.

Why is that third dimension so tempting? Because if the floor is crowded, perhaps the next bit belongs upstairs.

## Three different meanings of stacking

Memory marketing can make several distinct architectures sound like the same tower. It is worth separating them.

**3D NAND** already stores flash-memory cells in many vertical layers. It is non-volatile storage with different devices, access patterns and constraints from DRAM. The success of stacked flash does not mean DRAM can be copied into the same structure by changing the label on a drawing.

**High-bandwidth memory**, or HBM, stacks memory dies and connects them with dense vertical interconnects. It brings enormous bandwidth close to processors, and it is important to modern accelerators. But stacking finished DRAM dies is not the same as building a truly three-dimensional array of DRAM cells within a new cell architecture.

**3D DRAM** aims to change the cell array itself so that density can grow vertically rather than relying entirely on ever smaller planar dimensions. It raises its own questions: how to make and isolate the cells, how to read and refresh them, where to put the peripheral circuits, how to control defects and temperature, and whether the extra manufacturing steps improve cost per working bit. Micron says it is researching this direction, but has not committed to a commercial launch date. [2][5]

These distinctions are not pedantry. They separate a technology that ships in today's machines from a research direction that might determine what tomorrow's machines can afford to remember.

The October slides also discuss a proposed *vertical HBM* arrangement, with memory stacked on top of compute, rather than merely alongside it. That is another approach to the movement problem, the time and energy spent carrying data between a processor and the memory holding its working state. It is not interchangeable with 3D DRAM cell scaling. [2]

## The memory wall is not made of bricks

For decades, processors have become capable of performing operations faster than systems can supply all the data they need. This is the broad family of problems called the memory wall. Caches, prefetching, wider buses, faster DRAM, HBM, new packaging and clever algorithms are all attempts to get useful work done without waiting on the next byte.

The problem is particularly visible in large AI systems, where models may need vast amounts of memory capacity and bandwidth. But it is not an AI-only story. Games, scientific simulations, databases and ordinary software all inhabit the same physical world of memory latency, bandwidth, power and price.

The significance of Micron's decision is therefore not that a consumer should suddenly prefer one RAM module over another. There is no new 4F²-versus-6F² choice at the shop counter. It is that the cost and density of memory, years from now, depend on decisions that look embarrassingly small when written as algebra.

A percentage point of usable density at enormous manufacturing scale can matter more than a dramatic-sounding process name. And a theoretically smaller cell that adds too many steps, produces too few good dies or cannot be scaled economically may be a poorer bargain than a larger one with a reliable path forward.

> **A road map is also a record of the inventions a company has decided not to build.**
>
> *TOOLGLASS / EDITORIAL EXTRACT 02*

## The useful disappointment

There is a particular kind of engineering intelligence in abandoning an elegant idea after years of work. It is less photogenic than a prototype. There is no obvious hero image of a technology *not* being manufactured. It does, however, require an unusually serious understanding of the problem.

The 4F² cell is an attractive proposition. Its mathematics is not wrong. A smaller ideal footprint is a smaller ideal footprint. What Micron has argued is that, at the frontier it cares about, this number no longer describes the constraint that matters most. A capacitor, a factory and an accountant have entered the conversation, and none of them is impressed by the elegance of four squares.

Perhaps a rival will find a better way to build 4F². Perhaps 3D DRAM will arrive later, or prove more difficult than expected. The future remains contested. We should not convert one company's road map into a law of physics.

But there is a valuable lesson already. Computing history is full of ideas that were theoretically superior, technically possible, and commercially awkward. It is also full of supposedly exhausted technologies that survived because engineers found one more inventive way to use them.

A memory cell is not just the place where a bit sits. It is the agreement between charge, time, noise, geometry and manufacturing that allows the bit to exist at all. Sometimes the most advanced move is to stop shrinking the wrong part.

### Toolbox / the small vocabulary of very small memory

**DRAM:** Volatile memory that stores information as charge and must periodically refresh it. **1T1C:** One transistor and one capacitor per bit, a common modern DRAM-cell model. **F²:** An idealised area measure derived from a technology's minimum feature dimension; not a complete density or cost metric. **Pitch:** Centre-to-centre spacing between repeating structures, such as capacitors. **Sense amplifier:** Circuit that detects and restores a tiny signal from a DRAM cell. **Yield:** The share of manufactured devices that work within specification. **HBM:** High-bandwidth memory using stacked dies and dense connections. **3D DRAM:** A research direction for vertically arranged DRAM cells, distinct from conventional HBM packaging and 3D NAND flash.

### Read more / source desk

1. [Micron's 19 October announcement of the 21 October technology webinar](https://www.globenewswire.com/news-release/2026/10/19/3383394/14450/en/index.html), a primary company release. The decision itself is in the presentation and reported Q&A, not in this advance notice.
2. [Micron technology presentation, 21 October 2026, 33-slide mirror](https://6ix.com/deck/00znsgtd/micron-technology-technical-presentation-october-2026), particularly slides 15–17 and 20. Primary slide content reproduced by a third-party host; forward-looking statements are Micron's claims.
3. [IBM's history of dynamic random-access memory](https://www.ibm.com/history/dram), covering Robert Dennard's cell and the move beyond magnetic core.
4. [Intel's 1103 history](https://timeline.intel.com/1970/the-intel-1103-dram), including the 1970 launch and early market adoption.
5. [Anton Shilov, Tom's Hardware, 22 October 2026](https://www.tomshardware.com/pc-components/dram/micron-pulls-the-plug-on-future-4f2-dram-after-two-decades-of-research-in-dramatic-shift-company-says-architecture-offers-no-meaningful-density-advantages-increases-manufacturing-complexity-and-costs-and-has-fundamental-scaling-limitations), reporting the presentation and executive explanation. Independent reporting, not a substitute for testing fabrication claims.
6. [2025 Symposium on VLSI Technology and Circuits: 4F² DRAM with vertical gate and peri-under-cell architecture](https://doi.org/10.23919/VLSITechnologyandCir65189.2025.11075066), an IEEE technical paper documenting an integration demonstration.

**Evidence boundary:** Desk research only. No wafers, chips, production data or laboratory measurements were inspected. Micron's forward-looking performance and manufacturing claims are identified as such. The 4F² illustration is conceptual and not a faithful device cross-section.

**Art direction:** One conceptual machine plate: nominally smaller cell bays underneath capacitors that still require physical clearance, with a tentative vertical alternative at right. Spare cobalt and lime on paper. The image must not imply a measured transistor geometry or a photograph of Micron's process. Use two large pull quotes as freestanding typography, not boxed cards.

---

# Judy Malloy and the Novel With No Front Door

## Before the web made every word clickable, an artist and information programmer built a story you had to search. The result was part fiction, part database, and part argument about who gets to invent a medium.

**By Toolglass | 26 October 2026 | People / software and literature**

On 1 December 1986, readers of the Art Com Electronic Network on The WELL began receiving fragments of a story called *Uncle Roger*. The fragments appeared in an online discussion system, a few at a time, with keywords attached. There was a party in Woodside, California, a narrator called Jenny, and the overheard social weather of Silicon Valley's semiconductor business. It was a novel, but it did not arrive as a book. [1][2]

Its author, Judy Malloy, was not waiting for the World Wide Web. That did not exist as a public medium. Nor was she simply typing a conventional novel into a computer. She was trying to build a different way of telling a story, one in which the reader retrieved fragments and assembled a picture from them. The structure was part of the literature.

The astonishing thing is how many of the ingredients came from jobs that might have looked unrelated to art: library catalogues, technical information systems, database programming, the daily discipline of deciding where a piece of information belongs. Malloy's career makes a nonsense of the familiar division between the person who writes the words and the person who builds the machine.

She did both. Then she made the distinction difficult to maintain.

## The card catalogue before the cursor

Malloy's early career included work as a searcher and editor for the Library of Congress's union catalogue, and as a technical librarian for Ball Aerospace in Colorado. In her own account, she designed and programmed a computer catalogue for the Ball library in 1969. Other work included information organisation for technical and scientific collections. [3]

These are not glamorous origins for a literary revolution. A catalogue is meant to make a collection findable, not to make it sing. Its categories are supposed to be helpful and almost invisible. But information systems have a curious power: they decide which things are neighbours, what a query can retrieve, and which paths through a collection are even possible.

At the same time, Malloy was making visual art and writing. She later described how the logic of information structures gradually entered her studio work. By the late 1970s, she was producing artist's books and card-based narratives. A reader could move through drawings and texts without being forced along a single line. Works including *The Woodpile* (1979) and *Hearst Strip* (1980) explored arrangements that resembled both an artwork and a filing system. [3][4]

It is easy to describe these as primitive hypertext. That is true in one sense and misleading in another. They were physical works with their own visual language, not merely rough drafts for a website. A card catalogue asks you to choose, compare, return and discover. The hand participates in reading. The future digital version inherited that physical intelligence.

Malloy was not the only person experimenting with non-sequential narrative. Readers of Borges and Cortázar, and later users of computer systems such as Ted Nelson's Xanadu or Brown University's hypertext research, would recognise related ambitions. But a shared ambition is not the same as a shared implementation. Malloy came through the studio, the library and the bulletin board. Her route was unusually practical and unusually literary at once.

## The WELL was not the web

The WELL, founded in 1985, was an online community where people used conferencing software to hold discussions. Art Com Electronic Network, associated with curators Carl Loeffler and Fred Truck, made room there for artists working with software, networks and electronic publishing. The medium was text-heavy, social and still small enough that individual contributions could change its atmosphere. [1][5]

In the spring of 1986, Loeffler invited Malloy to work on the network. She began writing *Uncle Roger* that summer. Starting on 1 December, she used an ACEN discussion topic to publish the first file, *A Party in Woodside*, as a serial. The entries were small narrative units, often called *lexias*, accompanied by keywords. Readers could encounter the pieces in a public conversation while the work was still being written. [1][2]

That last detail matters. A contemporary web novel can be posted all at once and then discovered by strangers. *Uncle Roger* emerged in a live social environment. Readers were not merely anonymous future consumers; they were members of a network where the work could be discussed as it unfolded. Malloy's later recollections describe that audience responding to the work. [6]

There is a temptation to call it the first of everything: first hypertext novel, first online novel, first social-media fiction. Historians disagree about boundaries, predecessors and definitions. Toolglass will not manufacture a world-first trophy. What can be said securely is that *Uncle Roger* belongs to the earliest generation of born-digital literary works, and that its networked serial form predates the web by years. The Electronic Literature Directory and the ELMCIP archive document its versions and dates. [7][8]

The actual work was stranger than a milestone.

## The reader as search engine

The first network instalments carried keywords, but the links were not yet the live, clickable web links we take for granted. In 1987 Malloy programmed an interactive version using UNIX shell scripts for ACEN Datanet. She also made an Apple II version in Applesoft BASIC, later developing the larger three-part work and an IBM-compatible BASIC version. A web adaptation arrived in 1995. [1][2][7]

The technology was not an incidental wrapper. Malloy described *Uncle Roger* as a **narrabase**, a narrative database. Instead of turning a page to find out what happened next, the reader searched and retrieved units of the story. Keywords were not just labels on a finished book. They were part of the route by which the story became visible.

In a conventional novel, the author chooses a sequence. Even when a narrator is unreliable or a chronology fractured, the physical book usually presents the reader with a fixed succession of pages. Malloy's system made sequence into an action. A reader following one word could see one set of social connections; another reader, searching differently, could build another impression of the same world.

> **“Remember that at the time, there weren’t models for what I wanted to create.”**
>
> *JUDY MALLOY / THE LITERARY PLATFORM INTERVIEW, 2014 [5]*

The phrase is worth taking seriously. She was not filling a template called 'interactive fiction'. She was designing an interface for a kind of writing that lacked a settled template. There is a difference between authoring content *for* a medium and participating in the invention of the medium itself.

In *Uncle Roger*, the database metaphor even fitted the setting. The story was about the microelectronics culture of 1980s Silicon Valley, where information was valuable, people knew fragments of one another's business, and the machinery of work and power was changing quickly. The reader's own fragmentary access was not merely a trick; it echoed the society being described.

The first file involved a party. The second, *The Blue Notebook*, moved through remembered events and uncertain records. The third, *Terminals*, explored another part of the technological workplace. The Electronic Literature archives describe later versions using Boolean search and generative operations. These are not claims that every version had the same interface. Malloy repeatedly rebuilt the work as the available platforms changed. [2][8][9]

A 1995 web edition gave the project a different kind of reach. It also changed its conditions. A network of artists and technically experienced readers is not the same audience as the public web. Malloy has noted that the authorised web text includes revisions. Preservation here is not a matter of copying a disk image and declaring victory; the work has a history of versions, each with its own relationship between text, code and audience. [7]

## What a story can know

There is a deeper reason this is interesting to programmers. A database makes information retrievable according to a schema, even if the schema is implicit. A search system decides what counts as a match. A link makes one piece of text adjacent to another. Those choices can feel neutral in an office application. In a story, they become decisions about memory, attention and meaning.

Imagine a character appearing in three fragments. In one, they are a friend. In another, a colleague. In a third, a source of suspicion. The order in which a reader encounters those fragments changes the person they imagine. The database has not merely delivered the narrative; it has helped compose the reader's experience of it.

This is not an assertion that the software itself became a human author. Malloy wrote and structured the material. Her artistry lay partly in deciding how the material could be recombined, and how much freedom the reader should have. A work can be interactive without surrendering its authorship to chance.

The question reaches beyond literature. A modern research interface, a museum collection, a personal knowledge base or an AI assistant also mediates between a large body of material and the small selection that appears before us. Every retrieval system tells a partial story. Malloy was unusually early in treating that fact as an artistic resource rather than an inconvenience.

## A machine for bad advice

*Uncle Roger* was not the only oddity in the workshop. Malloy also made *Bad Information*, a project built around dubious advice and the comic possibilities of a searchable collection. People contributed material, and the work developed across installation and network forms. The premise is almost a parody of the solemn authority normally granted to information systems: what if a database were impeccably organised and full of terrible guidance? [3][10]

The joke has aged alarmingly well. Searchability does not confer truth. An answer can be retrieved quickly, formatted beautifully and still be nonsense. This is a lesson that modern AI products have spent a great deal of money rediscovering.

But *Bad Information* was not simply an early version of a misinformation warning. It was an artwork that used the social mechanics of collecting, categorising and sharing material. Its form made the audience part of the system. That is the recurring Malloy move: an information structure becomes a cultural structure.

There were other experiments. *YOU!* (1991) invited multiple contributors into an online poem. *its name was Penelope*, published by Eastgate in the early 1990s, used a different narrative architecture. The long poem *The Roar of Destiny Emanated From the Refrigerator* sounds like a title written by someone who knows perfectly well how absurd the technological sublime can become. Malloy's work did not settle into a single product or format. [3][11]

## Two writers, a research laboratory, and email

One of the most revealing later works is *Forward Anywhere*, made with researcher Cathy Marshall in the 1990s through the artist-in-residence programme at Xerox PARC. Their raw material included email exchanges about their lives and memories. Instead of starting with a fixed plot and illustrating it, the collaborators allowed resonances between their accounts to shape the hypertext. [12]

This is a useful reminder that the history of software is not only a parade of processors, languages and famous corporate laboratories. It is also a history of people asking what a medium might permit them to express. PARC is remembered for graphical interfaces, networking and the machinery of the modern office. Malloy and Marshall belong in that picture too, because they were exploring what those tools could mean for writing and human experience.

Malloy went on to document and advocate for other artists working at the intersection of technology and culture. She edited *Women, Art, and Technology* (MIT Press, 2003) and *Social Media Archeology and Poetics* (2016), and worked on Arts Wire and Leonardo-related publications. A School of the Art Institute of Chicago faculty profile lists her teaching *Women Artists in Cyberspace* in spring 2026. [3][11][13]

This is not a career of one early invention followed by a museum label. It is a long argument, made in artworks, code, teaching and editorial labour, that creative people should have a hand in shaping the tools through which culture moves.

> **She did not put a novel on a computer. She made the computer part of what a novel could be.**
>
> *TOOLGLASS / EDITORIAL EXTRACT 02*

## A front door is not always necessary

Today a great deal of digital writing arrives through systems designed to hide their workings. A person enters a prompt, a service produces a passage, and the apparatus in between is mostly inaccessible. This can be useful, but it makes it easy to mistake convenience for authorship and output for design.

Malloy's work points in another direction. She had a literary idea, then built and rebuilt the mechanisms that allowed it to exist. She treated a catalogue, a query, a keyword and a screen as things an artist could think with. Her software was not a black box that produced the story for her. It was an instrument she shaped to make the story possible.

The first readers of *Uncle Roger* did not need to understand every UNIX shell script to participate. They did, however, encounter a work whose structure was unmistakably part of its meaning. The interface did not disappear. It invited curiosity.

Forty years after those first postings on The WELL, we have an astonishing surplus of software that promises to make writing effortless. It is worth remembering a writer who chose the more difficult path: to invent a kind of writing and then make the computer learn how to hold it.

A book usually offers a front cover, a first page and a direction of travel. Malloy built a place where you could enter by a keyword, find a stranger at a party, follow a fragment of memory and come out with a story that belonged partly to the path you had taken. The novel had no single front door. That was the point.

### Toolbox / things a reader might want to look up

**The WELL:** A pioneering online community founded in 1985, known for its discussion forums. **ACEN:** Art Com Electronic Network, an early venue for electronic art and writing on The WELL. **BBS:** Bulletin board system, a networked place for messages and files before the public web. **Lexia:** A small unit of text used in hypertext writing; it may link to or be retrieved alongside others. **Narrabase:** Malloy's term for a narrative database in which searching and retrieval shape the reading experience. **Applesoft BASIC:** A BASIC interpreter for the Apple II, used by Malloy for a disk version of *Uncle Roger*. **UNIX shell scripts:** Programs made from command-line instructions; the 1987 online interactive version used them. **Xerox PARC:** A research laboratory whose artist-in-residence programme supported Malloy and Cathy Marshall's collaboration. **Eastgate:** A publisher associated with early literary hypertext.

### Read more / source desk

1. [Judy Malloy, notes on the creation of *Uncle Roger*](https://www.narrabase.net/uncleroger/uncle.html). First-person chronology of ACEN, the 1986 serial, UNIX scripts, BASIC and web versions.
2. [Judy Malloy, detailed history and version notes](https://www.narrabase.net/uncle_readme.html). Distinguishes non-live 1986 keyword links from the later interactive network implementation.
3. [Judy Malloy, autobiographical account](https://people.well.com/user/jmalloy/mybio.html). Library and technical-information career, artist's books, later work.
4. [Pathfinders project, Judy Malloy biography](https://scalar.usc.edu/works/pathfinders/judy-malloy.24). Scholarly documentation of her early artist's books and network practice.
5. [The Literary Platform, interview with Judy Malloy, April 2014](https://theliteraryplatform.com/news/2014/04/digital-literature-pioneers-judy-malloy-on-narrabases-80s-silicon-valley-and-e-literature-today/). Her explanation of narrabases, the Silicon Valley setting and the lack of models for her work.
6. [Pathfinders interview overview](https://scalar.usc.edu/works/pathfinders/malloys-interview.45). First-hand recorded recollections and archival commentary on the serial publication.
7. [Electronic Literature Directory, *Uncle Roger*](https://directory.eliterature.org/individual-work/642). Version chronology and authorised web edition.
8. [ELMCIP, *Uncle Roger*](https://elmcip.net/creative-work/uncle-roger). Technical media and exhibition history.
9. [The NEXT archive, *Uncle Roger*](https://the-next.org/works/827/). Notes on keyword searching, Boolean logic and the generative third file.
10. [The Literary Platform, second Malloy interview](https://theliteraryplatform.com/news/2014/05/digital-literature-pioneers-judy-malloy-on-collaboration-and-artists-networks-in-the-1980s/). Community and collaborative context.
11. [School of the Art Institute of Chicago, Judy Malloy faculty profile](https://www.saic.edu/profiles/faculty/judy-malloy). Later projects, publications and spring 2026 teaching.
12. [*Forward Anywhere* background](https://en.wikipedia.org/wiki/Forward_Anywhere). Secondary entry; use as a pointer to Malloy and Marshall's published collaboration rather than the final authority.
13. [ISEA archive, Judy Malloy's 1997 artist biography](https://www.isea-symposium-archives.org/person/judy-malloy/). A contemporary description of her Arts Wire and Xerox PARC work.

**Evidence boundary:** This is a desk-researched historical profile, not an interview. The 1986 and 1987 versions are not collapsed into one 'first hyperlinked web novel'. The direct Malloy quotation is sourced to her 2014 interview. All other pull-quote wording is Toolglass's own. No archival portrait or copyrighted story text is reproduced in the artwork.

**Art direction:** A conceptual index-machine with three narrative cards, routing lines and a small human figure operating the system from within. Not a portrait of Judy Malloy, not a reproduction of *Uncle Roger* pages. Two pull quotes, generously spaced and unboxed; exactly one subject quotation and one editorial excerpt.
