# Toolglass / Editorial bundle / 26 October 2026

**Status:** Prepared for Matthew's editorial review. **Not published.**

This week's editorial line is **the difference between an elegant representation and a working reality**. The lead feature follows a memory-cell layout that looked smaller on paper but failed Micron's economic/physical test. The person profile follows Judy Malloy, who refused to treat the story and the machine that carried it as separate things. The discoveries are a polyglot musical sequencer, a self-contained local model stack, and an evidence atlas that distinguishes mathematical output from mathematical knowledge.

## Contents

- `01-three-programs.md` — Sova, orangu, Mathematics Research & Evidence Atlas. Three desk-researched scouting notes, no hands-on claims.
- `02-the-smaller-square-that-wasnt.md` — long-form memory architecture feature (~2,600 words).
- `03-judy-malloy-and-the-novel-with-no-front-door.md` — historical person profile (~2,800 words).
- `toolglass-weekly-radar-2026-10-26.md` — combined issue manuscript.
- `preview.html` — local browser reading preview; artwork paths are relative.
- `art/*.svg` — editable concept plate masters; `art/*.webp` — exported website artwork; `art/contact-sheet.webp` — quick visual comparison.
- `production/build_art.py` — deterministic local vector-art builder using svgwrite, Inkscape and Pillow.
- `production/EDITORIAL-AND-ART-DIRECTION.md` — production brief for Luna.
- `production/SOURCE-AUDIT.md` — source/evidence boundaries and verification checklist.

## Design provenance

The 19 October original Toolglass bundle's vector build script and contact sheet were inspected as references, alongside the current public Toolglass CSS and editorial queue. This issue reuses the restrained paper / cobalt / lime / ink machine-folklore vocabulary, with new geometry drawn from scratch. No AI image generator, borrowed photograph or third-party art asset was used. The two SVG masters are editable, and the WebPs were exported with local Inkscape.

**Important boundary:** These graphics were built in this session's Linux vector environment, not on Matthew's Windows desktop with Luna. Before public integration, Luna should compare them with the *actual rendered* magazine, inspect type scale and mobile crops, and adjust locally where needed. Do not claim a Windows desktop test occurred.

## Publication rules

No publication is authorised by this scheduled editorial request. Matthew should review the copy first. Once approved, Luna can integrate into the canonical `matthewjameswatkins1978-cyber/Toolglass` site using the existing file-based editorial queue, typed content model, source links, evidence labels and artwork pipeline. Do not create a CMS or label the scouting notes TESTED.

The Micron feature's 4F²/6F² illustration is conceptual, not a fabrication cross-section or Micron drawing. The Judy Malloy image is a conceptual system plate, not a portrait or reproduction of *Uncle Roger*. Every article has exactly two large pull quotes in the manuscript; display them as freestanding type with generous space, not boxed quote cards.
