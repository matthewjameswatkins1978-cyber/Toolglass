---
title: Three Signals From the Workshop Floor
issue_date: 2026-10-19
section: Toolglass / Fresh Signals
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SCOUTED / SOURCE-LED / NO INSTALLATION OR TESTING
---

# Three Signals From the Workshop Floor

*An offline voice, a canvas that can be shared with machines, and a mobile network that is learning to look upwards. Three different answers to the question of where software ought to live.*

**TOOLGLASS / RADAR / 19 OCTOBER 2026**

These are scouting notes, not reviews. Toolglass has inspected public project descriptions, repositories and release material; it has **not installed, benchmarked, security-tested or endorsed** the software. Upstream promises are labelled as such. Three candidates were selected partly because they are unlike one another. A magazine ought not to discover the same AI coding assistant wearing three hats every Monday.

## 01 / Myna: the microphone stays at home

*Ubuntu's newest desktop feature has a surprisingly old ambition: make the computer take dictation without asking a remote server for permission.*

Imagine the least glamorous accessibility feature in the world. You press a key, say a sentence, and the words appear where the cursor is. No elaborate chat window. No conversation with an artificial personality. No account to create. It is the sort of facility that should have become unremarkable years ago.

On **15 October**, Canonical announced **Myna** as an opt-in speech-to-text feature of Ubuntu 26.10. Its public repository describes a client which sends microphone audio to locally running inference backends and injects the resulting transcript into the focused application. The project describes confined snaps and a Unix-socket boundary between client and inference components, and says audio is not persisted. These are architectural and privacy claims from the maintainers, **not conclusions from Toolglass network or filesystem testing**. [Canonical's announcement](https://canonical.com/blog/canonical-releases-ubuntu-26-10-stonking-stingray) and [Myna's source repository](https://github.com/canonical/myna) are the two useful starting points.

What makes Myna worth noticing is not that speech recognition has been invented again. It is the decision to put a small, accessible action into the desktop's ordinary working surface. This is a different philosophy from attaching a chat assistant to everything. The user wants text; the system supplies text. It also makes the location of computation an explicit design choice. On-device inference can avoid uploading audio to a cloud provider, although it does not automatically guarantee that every dependency, update path or application receiving the transcript is private.

There is a second, less visible story in the repository. The README acknowledges influence and code from **Murmure**, including parts of its Parakeet streaming approach. This is how open software ought to accumulate: an improvement arrives, its ancestry remains visible, and the next team builds on it. Myna's source is under **AGPL-3.0-or-later**. The repository also warns that features and protocols remain in heavy development and may break before a stable release. The distribution announcement is not the same as a claim that the whole project has stopped moving.

**What it might replace:** cloud dictation services for short desktop input, especially where offline operation or privacy is important. **What it does not replace:** a general transcription service with speaker diarisation, guaranteed specialist vocabulary or a fully tested accessibility workflow.

**The catch:** language coverage, model download sizes, latency on modest hardware, focus handling across Wayland applications and actual confinement behaviour all need testing. A voice interface can be accurate and still be unpleasant to use if it loses focus, inserts into the wrong window or has no clear correction loop.

**Next on the bench:** on a clean Ubuntu 26.10 machine, record the installation path, model sizes, offline network behaviour, hotkey/focus correctness, latency, error correction and how well it handles proper names and technical vocabulary. Include an accessibility tester rather than treating accuracy alone as the product.

**Sources:** [Canonical release announcement, 15 October 2026](https://canonical.com/blog/canonical-releases-ubuntu-26-10-stonking-stingray) · [Myna repository, architecture, acknowledgements and licence](https://github.com/canonical/myna)

## 02 / Doop: the design canvas grows another pair of hands

*The interesting question is not whether an agent can draw a web page. It is whether people and agents can work on the same design without losing the history of why it looks that way.*

A familiar ritual of AI design is to ask for a page, wait, inspect a screenshot, ask for a correction, wait again. The human watches the result arrive in parcels. The agent is somewhere behind the curtain. If two people and two agents are working together, the curtain starts to resemble a badly managed theatre.

**Doop**, launched publicly in September and still changing quickly, proposes a shared canvas. Its repository describes a multiplayer design surface where humans edit in a browser and agents use a built-in **Model Context Protocol (MCP)** server. Frames, comments, cursors and agent activity can be visible together. The important distinction is that the agent is not simply generating an image of a design. It is modifying an editable object in a common workspace. [Project site](https://doop.design/) · [Source and setup instructions](https://github.com/kgoedecke/doop).

There is a useful historical echo here. In the 1960s, Douglas Engelbart's team treated the computer as a medium for collective intellectual work; later collaborative editors made simultaneous human authorship routine. Doop extends the question to collaborators that are software agents. The hardest part is not getting a model to produce HTML. It is deciding which edits belong to whom, what an agent may touch, how changes are reconciled, and how the design's rationale survives the next enthusiastic rewrite.

Doop's documentation describes pinned examples, design decisions, persistent style rules, per-canvas permissions, and a route from frames to code. It also describes self-hosting with an embedded database for development or PostgreSQL. These are promising architectural choices, but a repository description cannot establish whether concurrency, undo history, export fidelity or permission checks survive hostile or merely chaotic use.

**A licensing and account-use warning deserves prominent type.** At this check, the [GitHub repository README](https://github.com/kgoedecke/doop) identifies **AGPL-3.0** and discusses rebranding obligations, while the [project website](https://doop.design/) says **MIT**. Treat the repository's licence file as the thing to inspect before reuse; do not assume the marketing page is current. The README also cautions that connecting a ChatGPT subscription through a third-party server may breach provider terms and recommends an API-key route instead. Toolglass has not tested or endorsed that subscription connection.

**What it might replace:** screenshot ping-pong and disconnected handoffs between a human designer and an agent, for teams comfortable with an experimental canvas. **What it does not replace:** mature design systems, accessibility review, provenance, licensing diligence or a production-grade code-review process.

**The catch:** rapid scope expansion, hosted-account boundaries, import/export fidelity, conflicting edits, and the possibility that an impressive real-time demonstration masks a fragile underlying document model.

**Next on the bench:** self-host a throwaway instance with two browsers and two deliberately restricted agents. Test simultaneous edits, rollback, permissions, HTML/CSS export, keyboard accessibility, and what happens when one agent sends malformed frame content. Resolve the licence discrepancy with maintainers before any code reuse.

**Sources:** [Doop project website](https://doop.design/) · [Repository README, licence and security notes](https://github.com/kgoedecke/doop)

## 03 / OCUDU 26.10: open software between a phone and the sky

*The least visible program in this week's selection is also the one with the most antennas.*

Most software readers think of a mobile network as something bought from a telecommunications company. The phone talks to a mast, the mast talks to a network, and the engineering between them belongs to a specialist industry of equipment vendors, standards bodies and expensive test facilities.

**OCUDU** is an open-source radio access network stack. Its **26.10** release, announced on **8 October**, adds baseline support for 3GPP Release 17 **non-terrestrial networks**, along with 8T8R antenna configurations, beam-management work, faster random-access options, positioning functions and security improvements. In plain English, the software that helps connect a phone to a terrestrial radio system is acquiring some of the language needed to work with networks that include satellites. [Foundation release](https://ocudu.org/news/ocudu-ecosystem-foundation-announces-ocudu-26-10-and-invites-developers-to-the-ocudu-ecosystem-developer-summit-october-20-22-near-washington-dc-to-learn-more-and-collaborate-on-open-source-ran/) · [Technical release notes](https://docs.ocudu.org/releases/release_notes/).

The interesting idea is not merely another feature flag in a large C++ project. It is that one of the most intricate pieces of modern infrastructure is being developed in a more inspectable, reusable form. OCUDU grew out of the srsRAN lineage; the project's current development home is **GitLab**, while its GitHub repository is a mirror. Its licensing is described as a **BSD 3-Clause Open MPI variant**, with an important qualification that implementations of 3GPP standards may involve additional patent obligations. [Project source](https://gitlab.com/ocudu/ocudu) · [GitHub mirror](https://github.com/ocudu/ocudu).

This is also where the difference between a release announcement and a working radio matters. The project's own 26.10 change log labels some new capabilities as **baseline** and specifically notes that the new O-RAN split 7.2b support has **not yet been tested with an O-RU** (the radio unit). Angle-based positioning and downlink positioning signals are likewise not yet end-to-end tested. That candour is useful evidence, not a reason to dismiss the project.

**What it might replace:** proprietary or closed laboratory RAN components in certain research, prototyping and integration environments. **What it does not replace:** licensed spectrum, certified radio hardware, a full commercial operator network, regulatory approval or an end-to-end satellite service.

**The catch:** hardware availability, timing-sensitive performance, standards compliance, interoperability and patent obligations. A radio stack is not the kind of project one evaluates by running `npm install` and admiring a screenshot.

**Next on the bench:** obtain a reproducible simulator-based build, map which 26.10 features have independent validation, inspect the public test reports, and talk to an engineer with access to compatible radios before making deployment claims. Start with the release notes' untested boundaries.

**Sources:** [OCUDU 26.10 technical release notes](https://docs.ocudu.org/releases/release_notes/) · [OCUDU Foundation announcement, 8 October 2026](https://ocudu.org/news/ocudu-ecosystem-foundation-announces-ocudu-26-10-and-invites-developers-to-the-ocudu-ecosystem-developer-summit-october-20-22-near-washington-dc-to-learn-more-and-collaborate-on-open-source-ran/) · [Source of truth](https://gitlab.com/ocudu/ocudu) · [srsRAN transition note](https://www.srsranproject.org/press_releases/srsran_becomes_ocudu/)

---

### Editorial decision, not a recommendation

**Myna** is the one most likely to affect ordinary people's daily experience. **Doop** has the most immediately interesting interface experiment and the most urgent licensing/account caveat. **OCUDU** is the reminder that some of the most consequential open software never appears on a desktop. None has been hands-on tested by Toolglass in this issue. Their evidence status remains **SCOUTED**.
