---
title: The Computer That Wanted to Settle Down
slug: the-computer-that-wanted-to-settle-down
section: Features
article_type: Long-form feature
issue_date: 2026-10-19
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SOURCE-CHECKED RESEARCH FEATURE / NO LAB REPLICATION
hero_art: art/equilibrium-machine.webp
---

# The Computer That Wanted to Settle Down

## For sixty years, we have built computers that fight their way through calculations. A new DNA machine asks what happens if the correct answer is simply the place the material most wants to be.

**TOOLGLASS / FEATURE / OCTOBER 2026**

To make this computer add ten and three, the researchers did not press a key.

They mixed short pieces of DNA with a longer strand, water and salt. They heated the mixture, then let it cool. As the temperature fell, the molecules settled into an arrangement. The arrangement represented thirteen.

There was no screen, no processor clock and no line of instructions marching through a silicon chip. The calculation happened because some molecular arrangements were more stable than others. The answer was designed to be the most attractive destination.

It sounds like an expensive way to rediscover arithmetic. It is. The experiment would not frighten a pocket calculator, which can add numbers considerably faster and without laboratory glassware. But in September 2026, researchers at Maynooth University published a paper in *Nature* demonstrating ten programs on what they call a **Scaffolded DNA Computer**. They reported more than 700 computations, some finishing in under a minute, others taking many hours. The remarkable part was not the arithmetic. It was the method by which the machine arrived at the answer. [The original open-access paper](https://www.nature.com/articles/s41586-026-10996-5) is unusually readable for a technical report of this sort.

The machine's central trick is a small reversal of an enormous assumption: instead of continually spending energy to force a system through a prescribed sequence, arrange the system so that *the answer is the state it naturally prefers*.

That sentence is easy to admire and rather harder to understand. To see why it matters, we need to visit a few old computer laboratories, a physicist's troublesome observation about erasing information, and a surprisingly productive corner of DNA origami.

## I / The price of making things happen

A digital computer is an astonishingly organised disturbance of matter. Its transistors switch, its clocks tick, its memory changes, and heat escapes into the room. It keeps information in carefully maintained states, often far from the conditions that an unattended physical system would eventually reach.

This is not simply an engineering failure. A running computer is doing work. But the relationship between computation and heat has troubled researchers for decades.

In **1961**, IBM physicist **Rolf Landauer** argued that logical irreversibility has a physical cost. When a device performs an operation that destroys information, such as erasing a bit without preserving its previous value, there is a minimum thermodynamic consequence. It is a deep statement, but it is often flattened into the misleading slogan that every logical operation must inevitably waste the same fixed quantity of energy. Landauer's insight was subtler: *information erasure* and physical dissipation are connected. [His original paper](https://doi.org/10.1147/RD.53.0183) remains the starting point.

In **1973**, **Charles Bennett** showed how a general computation could, in principle, be organised so that its logical steps were reversible. Keep enough information about the journey, and the machine can retrace it. Theoretically, the route to an answer need not be a sequence of irreversible little bonfires. [Bennett's paper](https://doi.org/10.1147/rd.176.0525) became part of the intellectual foundation of reversible computing.

There is a catch. Reversible does not mean effortless, instantaneous or free. Real devices must be built, controlled, supplied with materials, protected from noise and eventually read. The thermodynamic cost of computation cannot be waved away by a clever diagram.

But Bennett's work opened a more interesting possibility. Perhaps we have been confusing the particular machinery of our computers with the general nature of computing itself.

A river can find a low place without receiving a list of instructions about every stone. A magnet can settle into an orientation. Crystals can grow. The world is full of physical systems that explore possible states without a programmer telling them each individual move.

Could we arrange one of those systems so that the state it eventually reaches *means something*?

## II / When DNA stopped being only a message

DNA is familiar as a carrier of biological instructions, but its chemical properties make it useful for another job. Complementary sequences of bases tend to bind together. That gives a designer a way to specify which tiny objects should attach to which others.

In **1994**, **Leonard Adleman** used DNA molecules to demonstrate a computation involving paths through a small directed graph. It was a landmark not because it beat an electronic machine, but because it showed that a biochemical process could implement an algorithm. A graph problem had been translated into molecular operations. [Adleman's paper](https://doi.org/10.1126/science.7973651) helped launch a new field.

A few years later, **Erik Winfree** investigated the computational possibilities of DNA self-assembly. His work treated tiny molecular tiles as objects whose matching edges could encode rules. A pattern could grow by local interactions. The important idea was that *structure could carry a computation*. His [1998 thesis](https://thesis.caltech.edu/1866/) is still an excellent route into the subject.

Then, in **2006**, **Paul Rothemund** demonstrated DNA origami: a long DNA strand folded into designed shapes using many shorter 'staple' strands. Smiley faces, stars and maps were not useful computers, but they were an extraordinary proof of control. They showed that a designer could persuade a molecular material to assemble a surprisingly elaborate structure from the bottom up. [Rothemund's original paper](https://www.nature.com/articles/nature04586) is a small marvel of technical illustration.

These developments did not all solve the same problem. Some DNA computing schemes depend on staged reactions and careful timing; some self-assembly experiments seek a shape rather than an answer. The 2026 Maynooth work draws from this history while changing the design objective. It asks whether the *correct computation* can be made thermodynamically favoured over its alternatives.

That is the important word: **favoured**. Not guaranteed by magic. Not a machine that has become infallible. A system whose chemistry has been designed to give the desired configuration a strong advantage.

## III / A programme made of competing pieces

Imagine a strip of material divided into numbered docking places. At each place, several little tiles might fit. Each tile carries two kinds of information. One part identifies where it belongs on the strip. The other parts must agree with the neighbouring tiles.

The strip is the **scaffold**. The tiles are short DNA strands. Their matching regions encode a program and its input.

A tile may attach to the correct position while disagreeing with its neighbour. That is a computational mistake. But it is also, by design, a less favourable chemical arrangement. Another tile can compete for the place, and the incorrect arrangement can be replaced. When all neighbouring rules agree, the structure is more stable.

This is the key architectural difference from a conventional sequence of instructions. There is no little foreman travelling down the scaffold checking every result. The rules are embedded in the binding relationships. Local competition does much of the work.

The researchers use a **finite-state-machine** description to compile certain algorithms into these tiles. In binary addition, for example, the state that must travel from one digit to the next is the carry. The tile choices encode how the current input bits and the previous carry determine the next carry and output. It is recognisable computer science, but implemented as a set of molecular preferences.

The experiments reported ten programs, including bit copy, parity detection, multiplication by three, division by two, balanced-bracket recognition and addition. A four-position system could evaluate small cases quickly; the paper reports typical three-hour cooling protocols and, for short instances, accelerated runs yielding distinguishable outputs in roughly a minute or less. [Methods and measurements are in the primary paper](https://www.nature.com/articles/s41586-026-10996-5).

The machine is not simply waiting for DNA to arrange itself into a decorative shape. It has been given a *computational landscape*. Correct local relationships lower the cost of a configuration. Incorrect ones can be displaced. The chemistry supplies a search procedure.

If this reminds you of optimisation, that is not an accident. Many mathematical methods seek low-energy or low-cost states. But ordinary software optimisation algorithms still run on machines that consume energy to execute every step. Here the researchers have built a physical medium in which a useful solution corresponds to the material's favoured state.

The distinction is not a small one.

## IV / The trouble with large numbers

It would be pleasant to announce that a few drops of DNA are about to replace a data centre. The evidence does not support that conclusion.

When the team scaled up to adding two **25-bit numbers**, they reported a computation involving **100 bits of input, carry and output-related work**. It was a substantial demonstration for this medium. It was also slow: some large cases took **up to 14 hours**. The authors themselves discuss the difficulty of scaling, including uneven binding energies, slower interactions and less cooperative energy landscapes. Their larger bit-copy experiment also had lower yields than their small, carefully controlled cases.

Those numbers matter. An electronic calculator does the same arithmetic before a person can finish asking the question. A molecular machine must be prepared, heated, cooled and measured. Synthesising the strands takes resources; the laboratory apparatus consumes energy; and a fluorescence readout is not the same thing as a ready-made digital interface. The phrase 'no fuel' in a description of the molecular reaction must not be mistaken for 'no energy or material cost anywhere in the process'.

There is another distinction worth preserving. A thermodynamically favoured state is a probability distribution with a particularly desirable outcome, not a divine promise. The paper gives both physical measurements and theoretical arguments for how target states can dominate. It does not prove that every arbitrarily large real-world DNA program will converge quickly and perfectly.

Even the attractive claim about reusability has a precise meaning. The researchers showed that they could **renew** certain calculations by adding strands to change the input and reheating the mixture, with a bit-copy program repeated **25 times**. They did not wash the chemistry into a fresh, costless machine. They managed the changing equilibrium. That is cleverer, and more useful, than the slogan 'reusable DNA computer' suggests.

There is a reason to enjoy this limitation rather than hide it. The gap between a four-position success and a 25-position struggle is where engineering begins. It is where elegant theory meets real molecules that refuse to read the paper.

## V / What sort of computer would want this?

The immediate answer is probably not a laptop.

A laptop needs predictable response times, billions of repeated operations, cheap memory, straightforward input and output, and a manufacturing ecosystem that has spent decades learning how to make transistors reliable. DNA is not competing with that on ordinary arithmetic.

The interesting applications are where computation and chemistry already occupy the same world. Imagine a molecular system that responds to several local signals and settles into a configuration that performs a useful sensing or control function. Or a material whose assembly embodies a decision about what structure to form. Or DNA data-storage and molecular-robotics systems in which information processing does not need to leave the chemical medium merely to return as a control signal.

Those are directions suggested by the researchers, not products they have demonstrated. The leap from laboratory scaffold to useful device is large. So is the leap from thermodynamic favourability to a practical claim of lower *whole-system* energy use.

Nevertheless, the experiment changes the question we can ask.

Much of computer engineering is concerned with making a machine obey: more precise clocks, stronger isolation, more error correction, more carefully staged operations. That approach has produced a technological civilisation. But it is not the only conceivable relationship between information and matter.

The Maynooth machine is designed less like a regiment of switches and more like a landscape with one particularly inviting valley. It does not command every molecule to take the correct path. It makes the correct destination attractive enough that the molecules can find it through their own local interactions.

The distinction feels philosophical because it is philosophical. But it is also a working experiment, with numbers, error bars, awkward scale-up problems and a paper anyone can read.

That is why it deserves attention now. Not because DNA has finally defeated silicon. It hasn't. But because a research team has demonstrated a different way to make matter perform an algorithm, and the old assumption that a computer must always be driven through every step looks a little less inevitable.

The future computer may still be a box that gets hot.

It is now easier to imagine another kind: one that does some of its thinking by being allowed to settle down.

---

### Toolbox translated

**Scaffold:** a long DNA strand providing ordered positions to which shorter strands can bind. It is the physical spine of the program.

**Compute tile:** a short DNA strand whose binding regions encode a position and computational relationships with neighbours.

**Thermodynamic equilibrium:** a state in which the system's large-scale properties no longer show a net tendency to change under fixed conditions. Here the researchers design the desired output to be energetically favoured.

**Finite-state machine:** a simple model of computation with a limited number of internal states. Addition can use a carry bit as state passed between digit positions.

**Annealing:** heating and cooling a molecular mixture to let bonds break, reform and settle into more favourable arrangements.

**Yield:** an experimental measure of how much of the expected output signal or structure is obtained. It is not interchangeable with a guarantee of correct answers on every future input.

### Read more / primary shelf

1. [Stérin, Eshra, Evans, Adio & Woods, *A thermodynamically favoured molecular computer*, Nature, 16 September 2026](https://www.nature.com/articles/s41586-026-10996-5). The actual experiment, open access; begin with the figures and discussion.
2. [Maynooth University, research summary](https://www.maynoothuniversity.ie/node/565228). A clear account of the results and intended directions.
3. [Rolf Landauer, *Irreversibility and Heat Generation in the Computing Process* (1961)](https://doi.org/10.1147/RD.53.0183). The older argument about information and physical cost.
4. [Charles H. Bennett, *Logical Reversibility of Computation* (1973)](https://doi.org/10.1147/rd.176.0525). Why logical computation need not destroy information at every step.
5. [Leonard Adleman, *Molecular Computation of Solutions to Combinatorial Problems* (1994)](https://doi.org/10.1126/science.7973651). The early DNA-computing demonstration.
6. [Erik Winfree, *Algorithmic Self-Assembly of DNA* (1998)](https://thesis.caltech.edu/1866/). The conceptual bridge between computation and molecular assembly.
7. [Paul Rothemund, *Folding DNA to Create Nanoscale Shapes and Patterns* (2006)](https://www.nature.com/articles/nature04586). The DNA-origami lineage.

**Evidence boundary:** This is a source-led research feature. Toolglass did not reproduce the laboratory results or independently measure energy consumption. Performance and yields refer to the paper's experimental systems and should not be generalised to useful molecular computers. Artwork is an original conceptual plate, not a molecular structure measured by microscopy.
