# Toolglass Weekly Editorial Bundle / 19 October 2026

**Status:** DRAFT / Matthew's editorial review. **Not published.**

**Contents:** Three source-led scouting notes, one substantial research feature, one person profile, two locally rendered and editable concept plates, and the script used to draw them. Approximately 6,670 words of copy.

## Editorial selection

| Lane | Subject | Why now | Evidence |
| --- | --- | --- | --- |
| Three programs | Myna / Doop / OCUDU 26.10 | 15 October Ubuntu release / September design-canvas debut / 8 October open RAN release | SCOUTED; not installed or tested |
| Feature | The Computer That Wanted to Settle Down | September 2026 *Nature* paper on thermodynamically favoured DNA computing | Source-checked research; no lab replication |
| Profile | Mary Allen Wilkes and the Computer in the Living Room | A neglected early interactive-computing pioneer, documented through her own oral history and papers | Source-checked historical profile |

## Files

- `01-three-programs.md` — three scouting pieces, limitations, primary links, suggested tests.
- `02-the-computer-that-wanted-to-settle-down.md` — feature with historical lineage, limitations, toolbox and Read More.
- `03-mary-allen-wilkes.md` — person profile with **exactly two original editorial pull quotes**, toolbox and Read More.
- `art/equilibrium-machine.svg` and `.webp` — editable concept plate and website-ready export.
- `art/linc-living-room-machine.svg` and `.webp` — editable concept plate and website-ready export.
- `art/contact-sheet.webp` — visual proof.
- `production/build_art.py` — reproducible local vector drawing and export script; uses `svgwrite`, `Pillow` and Inkscape. No image generation.
- `production/EDITORIAL-AND-ART-DIRECTION.md` — local agent handoff and final checks.

## Artwork and authorship

The art was built in the available **local software environment for this session** from original SVG geometry, using the palette, typography and layout vocabulary observed in Toolglass's existing `mxc-authority-machine.svg` and `solomon-learning-machine.svg`. It was **not produced by an image-generation model** and no third-party image assets were copied. The original Toolglass repository artwork was inspected as SVG structure; this session could not operate Matthew's Windows desktop or have Luna inspect the rendered magazine on that machine. These are production-ready *proposals* for Luna's final local visual pass, not a claim that the established Windows workflow has already run.

Both concept plates deliberately avoid literal historical or scientific reconstructions. Captions must not present them as photographs, microscopy or accurate instrument schematics.

## Rights and evidence

Article text and vector artwork are newly authored for this bundle. Linked papers, repositories and museum sources remain with their respective rights holders; none of their figures or photos were reproduced. Direct quotations in the profile's pull quotes are **not** attributed to the subject because they are original Toolglass lines. Source checks are from 19 October 2026; see article footnotes for primary references.

**Important open issue:** Doop's site says MIT while its GitHub repository says AGPL-3.0. The scouting piece flags this rather than silently choosing one. Its README also cautions against connecting ChatGPT subscriptions through an unsanctioned third-party server. The OCUDU release notes explicitly mark some capabilities as baseline and untested with radio hardware. Preserve these caveats.

**No auto-publication.** Matthew adds his voice, Luna completes the established local artwork and site integration pass, and Toolglass's editorial evidence and deployment gates remain in force.
