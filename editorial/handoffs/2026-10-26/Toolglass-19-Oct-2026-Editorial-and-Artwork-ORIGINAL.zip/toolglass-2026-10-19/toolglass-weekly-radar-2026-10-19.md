# TOOLGLASS / WEEKLY EDITORIAL BUNDLE / 19 OCTOBER 2026

**For Matthew’s review. Not published.**  
**Evidence:** three source-led scouts; two source-checked editorial features. No hands-on software testing or laboratory replication.

This combined reading copy gathers the three articles. Editable artwork masters, WebP exports and production notes are in the accompanying ZIP.

---

---
title: Three Signals From the Workshop Floor
issue_date: 2026-10-19
section: Toolglass / Fresh Signals
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SCOUTED / SOURCE-LED / NO INSTALLATION OR TESTING
---

# Three Signals From the Workshop Floor

*An offline voice, a canvas that can be shared with machines, and a mobile network that is learning to look upwards. Three different answers to the question of where software ought to live.*

**TOOLGLASS / RADAR / 19 OCTOBER 2026**

These are scouting notes, not reviews. Toolglass has inspected public project descriptions, repositories and release material; it has **not installed, benchmarked, security-tested or endorsed** the software. Upstream promises are labelled as such. Three candidates were selected partly because they are unlike one another. A magazine ought not to discover the same AI coding assistant wearing three hats every Monday.

## 01 / Myna: the microphone stays at home

*Ubuntu's newest desktop feature has a surprisingly old ambition: make the computer take dictation without asking a remote server for permission.*

Imagine the least glamorous accessibility feature in the world. You press a key, say a sentence, and the words appear where the cursor is. No elaborate chat window. No conversation with an artificial personality. No account to create. It is the sort of facility that should have become unremarkable years ago.

On **15 October**, Canonical announced **Myna** as an opt-in speech-to-text feature of Ubuntu 26.10. Its public repository describes a client which sends microphone audio to locally running inference backends and injects the resulting transcript into the focused application. The project describes confined snaps and a Unix-socket boundary between client and inference components, and says audio is not persisted. These are architectural and privacy claims from the maintainers, **not conclusions from Toolglass network or filesystem testing**. [Canonical's announcement](https://canonical.com/blog/canonical-releases-ubuntu-26-10-stonking-stingray) and [Myna's source repository](https://github.com/canonical/myna) are the two useful starting points.

What makes Myna worth noticing is not that speech recognition has been invented again. It is the decision to put a small, accessible action into the desktop's ordinary working surface. This is a different philosophy from attaching a chat assistant to everything. The user wants text; the system supplies text. It also makes the location of computation an explicit design choice. On-device inference can avoid uploading audio to a cloud provider, although it does not automatically guarantee that every dependency, update path or application receiving the transcript is private.

There is a second, less visible story in the repository. The README acknowledges influence and code from **Murmure**, including parts of its Parakeet streaming approach. This is how open software ought to accumulate: an improvement arrives, its ancestry remains visible, and the next team builds on it. Myna's source is under **AGPL-3.0-or-later**. The repository also warns that features and protocols remain in heavy development and may break before a stable release. The distribution announcement is not the same as a claim that the whole project has stopped moving.

**What it might replace:** cloud dictation services for short desktop input, especially where offline operation or privacy is important. **What it does not replace:** a general transcription service with speaker diarisation, guaranteed specialist vocabulary or a fully tested accessibility workflow.

**The catch:** language coverage, model download sizes, latency on modest hardware, focus handling across Wayland applications and actual confinement behaviour all need testing. A voice interface can be accurate and still be unpleasant to use if it loses focus, inserts into the wrong window or has no clear correction loop.

**Next on the bench:** on a clean Ubuntu 26.10 machine, record the installation path, model sizes, offline network behaviour, hotkey/focus correctness, latency, error correction and how well it handles proper names and technical vocabulary. Include an accessibility tester rather than treating accuracy alone as the product.

**Sources:** [Canonical release announcement, 15 October 2026](https://canonical.com/blog/canonical-releases-ubuntu-26-10-stonking-stingray) · [Myna repository, architecture, acknowledgements and licence](https://github.com/canonical/myna)

## 02 / Doop: the design canvas grows another pair of hands

*The interesting question is not whether an agent can draw a web page. It is whether people and agents can work on the same design without losing the history of why it looks that way.*

A familiar ritual of AI design is to ask for a page, wait, inspect a screenshot, ask for a correction, wait again. The human watches the result arrive in parcels. The agent is somewhere behind the curtain. If two people and two agents are working together, the curtain starts to resemble a badly managed theatre.

**Doop**, launched publicly in September and still changing quickly, proposes a shared canvas. Its repository describes a multiplayer design surface where humans edit in a browser and agents use a built-in **Model Context Protocol (MCP)** server. Frames, comments, cursors and agent activity can be visible together. The important distinction is that the agent is not simply generating an image of a design. It is modifying an editable object in a common workspace. [Project site](https://doop.design/) · [Source and setup instructions](https://github.com/kgoedecke/doop).

There is a useful historical echo here. In the 1960s, Douglas Engelbart's team treated the computer as a medium for collective intellectual work; later collaborative editors made simultaneous human authorship routine. Doop extends the question to collaborators that are software agents. The hardest part is not getting a model to produce HTML. It is deciding which edits belong to whom, what an agent may touch, how changes are reconciled, and how the design's rationale survives the next enthusiastic rewrite.

Doop's documentation describes pinned examples, design decisions, persistent style rules, per-canvas permissions, and a route from frames to code. It also describes self-hosting with an embedded database for development or PostgreSQL. These are promising architectural choices, but a repository description cannot establish whether concurrency, undo history, export fidelity or permission checks survive hostile or merely chaotic use.

**A licensing and account-use warning deserves prominent type.** At this check, the [GitHub repository README](https://github.com/kgoedecke/doop) identifies **AGPL-3.0** and discusses rebranding obligations, while the [project website](https://doop.design/) says **MIT**. Treat the repository's licence file as the thing to inspect before reuse; do not assume the marketing page is current. The README also cautions that connecting a ChatGPT subscription through a third-party server may breach provider terms and recommends an API-key route instead. Toolglass has not tested or endorsed that subscription connection.

**What it might replace:** screenshot ping-pong and disconnected handoffs between a human designer and an agent, for teams comfortable with an experimental canvas. **What it does not replace:** mature design systems, accessibility review, provenance, licensing diligence or a production-grade code-review process.

**The catch:** rapid scope expansion, hosted-account boundaries, import/export fidelity, conflicting edits, and the possibility that an impressive real-time demonstration masks a fragile underlying document model.

**Next on the bench:** self-host a throwaway instance with two browsers and two deliberately restricted agents. Test simultaneous edits, rollback, permissions, HTML/CSS export, keyboard accessibility, and what happens when one agent sends malformed frame content. Resolve the licence discrepancy with maintainers before any code reuse.

**Sources:** [Doop project website](https://doop.design/) · [Repository README, licence and security notes](https://github.com/kgoedecke/doop)

## 03 / OCUDU 26.10: open software between a phone and the sky

*The least visible program in this week's selection is also the one with the most antennas.*

Most software readers think of a mobile network as something bought from a telecommunications company. The phone talks to a mast, the mast talks to a network, and the engineering between them belongs to a specialist industry of equipment vendors, standards bodies and expensive test facilities.

**OCUDU** is an open-source radio access network stack. Its **26.10** release, announced on **8 October**, adds baseline support for 3GPP Release 17 **non-terrestrial networks**, along with 8T8R antenna configurations, beam-management work, faster random-access options, positioning functions and security improvements. In plain English, the software that helps connect a phone to a terrestrial radio system is acquiring some of the language needed to work with networks that include satellites. [Foundation release](https://ocudu.org/news/ocudu-ecosystem-foundation-announces-ocudu-26-10-and-invites-developers-to-the-ocudu-ecosystem-developer-summit-october-20-22-near-washington-dc-to-learn-more-and-collaborate-on-open-source-ran/) · [Technical release notes](https://docs.ocudu.org/releases/release_notes/).

The interesting idea is not merely another feature flag in a large C++ project. It is that one of the most intricate pieces of modern infrastructure is being developed in a more inspectable, reusable form. OCUDU grew out of the srsRAN lineage; the project's current development home is **GitLab**, while its GitHub repository is a mirror. Its licensing is described as a **BSD 3-Clause Open MPI variant**, with an important qualification that implementations of 3GPP standards may involve additional patent obligations. [Project source](https://gitlab.com/ocudu/ocudu) · [GitHub mirror](https://github.com/ocudu/ocudu).

This is also where the difference between a release announcement and a working radio matters. The project's own 26.10 change log labels some new capabilities as **baseline** and specifically notes that the new O-RAN split 7.2b support has **not yet been tested with an O-RU** (the radio unit). Angle-based positioning and downlink positioning signals are likewise not yet end-to-end tested. That candour is useful evidence, not a reason to dismiss the project.

**What it might replace:** proprietary or closed laboratory RAN components in certain research, prototyping and integration environments. **What it does not replace:** licensed spectrum, certified radio hardware, a full commercial operator network, regulatory approval or an end-to-end satellite service.

**The catch:** hardware availability, timing-sensitive performance, standards compliance, interoperability and patent obligations. A radio stack is not the kind of project one evaluates by running `npm install` and admiring a screenshot.

**Next on the bench:** obtain a reproducible simulator-based build, map which 26.10 features have independent validation, inspect the public test reports, and talk to an engineer with access to compatible radios before making deployment claims. Start with the release notes' untested boundaries.

**Sources:** [OCUDU 26.10 technical release notes](https://docs.ocudu.org/releases/release_notes/) · [OCUDU Foundation announcement, 8 October 2026](https://ocudu.org/news/ocudu-ecosystem-foundation-announces-ocudu-26-10-and-invites-developers-to-the-ocudu-ecosystem-developer-summit-october-20-22-near-washington-dc-to-learn-more-and-collaborate-on-open-source-ran/) · [Source of truth](https://gitlab.com/ocudu/ocudu) · [srsRAN transition note](https://www.srsranproject.org/press_releases/srsran_becomes_ocudu/)

---

### Editorial decision, not a recommendation

**Myna** is the one most likely to affect ordinary people's daily experience. **Doop** has the most immediately interesting interface experiment and the most urgent licensing/account caveat. **OCUDU** is the reminder that some of the most consequential open software never appears on a desktop. None has been hands-on tested by Toolglass in this issue. Their evidence status remains **SCOUTED**.


---

---
title: The Computer That Wanted to Settle Down
slug: the-computer-that-wanted-to-settle-down
section: Features
article_type: Long-form feature
issue_date: 2026-10-19
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SOURCE-CHECKED RESEARCH FEATURE / NO LAB REPLICATION
hero_art: art/equilibrium-machine.webp
---

# The Computer That Wanted to Settle Down

## For sixty years, we have built computers that fight their way through calculations. A new DNA machine asks what happens if the correct answer is simply the place the material most wants to be.

**TOOLGLASS / FEATURE / OCTOBER 2026**

To make this computer add ten and three, the researchers did not press a key.

They mixed short pieces of DNA with a longer strand, water and salt. They heated the mixture, then let it cool. As the temperature fell, the molecules settled into an arrangement. The arrangement represented thirteen.

There was no screen, no processor clock and no line of instructions marching through a silicon chip. The calculation happened because some molecular arrangements were more stable than others. The answer was designed to be the most attractive destination.

It sounds like an expensive way to rediscover arithmetic. It is. The experiment would not frighten a pocket calculator, which can add numbers considerably faster and without laboratory glassware. But in September 2026, researchers at Maynooth University published a paper in *Nature* demonstrating ten programs on what they call a **Scaffolded DNA Computer**. They reported more than 700 computations, some finishing in under a minute, others taking many hours. The remarkable part was not the arithmetic. It was the method by which the machine arrived at the answer. [The original open-access paper](https://www.nature.com/articles/s41586-026-10996-5) is unusually readable for a technical report of this sort.

The machine's central trick is a small reversal of an enormous assumption: instead of continually spending energy to force a system through a prescribed sequence, arrange the system so that *the answer is the state it naturally prefers*.

That sentence is easy to admire and rather harder to understand. To see why it matters, we need to visit a few old computer laboratories, a physicist's troublesome observation about erasing information, and a surprisingly productive corner of DNA origami.

## I / The price of making things happen

A digital computer is an astonishingly organised disturbance of matter. Its transistors switch, its clocks tick, its memory changes, and heat escapes into the room. It keeps information in carefully maintained states, often far from the conditions that an unattended physical system would eventually reach.

This is not simply an engineering failure. A running computer is doing work. But the relationship between computation and heat has troubled researchers for decades.

In **1961**, IBM physicist **Rolf Landauer** argued that logical irreversibility has a physical cost. When a device performs an operation that destroys information, such as erasing a bit without preserving its previous value, there is a minimum thermodynamic consequence. It is a deep statement, but it is often flattened into the misleading slogan that every logical operation must inevitably waste the same fixed quantity of energy. Landauer's insight was subtler: *information erasure* and physical dissipation are connected. [His original paper](https://doi.org/10.1147/RD.53.0183) remains the starting point.

In **1973**, **Charles Bennett** showed how a general computation could, in principle, be organised so that its logical steps were reversible. Keep enough information about the journey, and the machine can retrace it. Theoretically, the route to an answer need not be a sequence of irreversible little bonfires. [Bennett's paper](https://doi.org/10.1147/rd.176.0525) became part of the intellectual foundation of reversible computing.

There is a catch. Reversible does not mean effortless, instantaneous or free. Real devices must be built, controlled, supplied with materials, protected from noise and eventually read. The thermodynamic cost of computation cannot be waved away by a clever diagram.

But Bennett's work opened a more interesting possibility. Perhaps we have been confusing the particular machinery of our computers with the general nature of computing itself.

A river can find a low place without receiving a list of instructions about every stone. A magnet can settle into an orientation. Crystals can grow. The world is full of physical systems that explore possible states without a programmer telling them each individual move.

Could we arrange one of those systems so that the state it eventually reaches *means something*?

## II / When DNA stopped being only a message

DNA is familiar as a carrier of biological instructions, but its chemical properties make it useful for another job. Complementary sequences of bases tend to bind together. That gives a designer a way to specify which tiny objects should attach to which others.

In **1994**, **Leonard Adleman** used DNA molecules to demonstrate a computation involving paths through a small directed graph. It was a landmark not because it beat an electronic machine, but because it showed that a biochemical process could implement an algorithm. A graph problem had been translated into molecular operations. [Adleman's paper](https://doi.org/10.1126/science.7973651) helped launch a new field.

A few years later, **Erik Winfree** investigated the computational possibilities of DNA self-assembly. His work treated tiny molecular tiles as objects whose matching edges could encode rules. A pattern could grow by local interactions. The important idea was that *structure could carry a computation*. His [1998 thesis](https://thesis.caltech.edu/1866/) is still an excellent route into the subject.

Then, in **2006**, **Paul Rothemund** demonstrated DNA origami: a long DNA strand folded into designed shapes using many shorter 'staple' strands. Smiley faces, stars and maps were not useful computers, but they were an extraordinary proof of control. They showed that a designer could persuade a molecular material to assemble a surprisingly elaborate structure from the bottom up. [Rothemund's original paper](https://www.nature.com/articles/nature04586) is a small marvel of technical illustration.

These developments did not all solve the same problem. Some DNA computing schemes depend on staged reactions and careful timing; some self-assembly experiments seek a shape rather than an answer. The 2026 Maynooth work draws from this history while changing the design objective. It asks whether the *correct computation* can be made thermodynamically favoured over its alternatives.

That is the important word: **favoured**. Not guaranteed by magic. Not a machine that has become infallible. A system whose chemistry has been designed to give the desired configuration a strong advantage.

## III / A programme made of competing pieces

Imagine a strip of material divided into numbered docking places. At each place, several little tiles might fit. Each tile carries two kinds of information. One part identifies where it belongs on the strip. The other parts must agree with the neighbouring tiles.

The strip is the **scaffold**. The tiles are short DNA strands. Their matching regions encode a program and its input.

A tile may attach to the correct position while disagreeing with its neighbour. That is a computational mistake. But it is also, by design, a less favourable chemical arrangement. Another tile can compete for the place, and the incorrect arrangement can be replaced. When all neighbouring rules agree, the structure is more stable.

This is the key architectural difference from a conventional sequence of instructions. There is no little foreman travelling down the scaffold checking every result. The rules are embedded in the binding relationships. Local competition does much of the work.

The researchers use a **finite-state-machine** description to compile certain algorithms into these tiles. In binary addition, for example, the state that must travel from one digit to the next is the carry. The tile choices encode how the current input bits and the previous carry determine the next carry and output. It is recognisable computer science, but implemented as a set of molecular preferences.

The experiments reported ten programs, including bit copy, parity detection, multiplication by three, division by two, balanced-bracket recognition and addition. A four-position system could evaluate small cases quickly; the paper reports typical three-hour cooling protocols and, for short instances, accelerated runs yielding distinguishable outputs in roughly a minute or less. [Methods and measurements are in the primary paper](https://www.nature.com/articles/s41586-026-10996-5).

The machine is not simply waiting for DNA to arrange itself into a decorative shape. It has been given a *computational landscape*. Correct local relationships lower the cost of a configuration. Incorrect ones can be displaced. The chemistry supplies a search procedure.

If this reminds you of optimisation, that is not an accident. Many mathematical methods seek low-energy or low-cost states. But ordinary software optimisation algorithms still run on machines that consume energy to execute every step. Here the researchers have built a physical medium in which a useful solution corresponds to the material's favoured state.

The distinction is not a small one.

## IV / The trouble with large numbers

It would be pleasant to announce that a few drops of DNA are about to replace a data centre. The evidence does not support that conclusion.

When the team scaled up to adding two **25-bit numbers**, they reported a computation involving **100 bits of input, carry and output-related work**. It was a substantial demonstration for this medium. It was also slow: some large cases took **up to 14 hours**. The authors themselves discuss the difficulty of scaling, including uneven binding energies, slower interactions and less cooperative energy landscapes. Their larger bit-copy experiment also had lower yields than their small, carefully controlled cases.

Those numbers matter. An electronic calculator does the same arithmetic before a person can finish asking the question. A molecular machine must be prepared, heated, cooled and measured. Synthesising the strands takes resources; the laboratory apparatus consumes energy; and a fluorescence readout is not the same thing as a ready-made digital interface. The phrase 'no fuel' in a description of the molecular reaction must not be mistaken for 'no energy or material cost anywhere in the process'.

There is another distinction worth preserving. A thermodynamically favoured state is a probability distribution with a particularly desirable outcome, not a divine promise. The paper gives both physical measurements and theoretical arguments for how target states can dominate. It does not prove that every arbitrarily large real-world DNA program will converge quickly and perfectly.

Even the attractive claim about reusability has a precise meaning. The researchers showed that they could **renew** certain calculations by adding strands to change the input and reheating the mixture, with a bit-copy program repeated **25 times**. They did not wash the chemistry into a fresh, costless machine. They managed the changing equilibrium. That is cleverer, and more useful, than the slogan 'reusable DNA computer' suggests.

There is a reason to enjoy this limitation rather than hide it. The gap between a four-position success and a 25-position struggle is where engineering begins. It is where elegant theory meets real molecules that refuse to read the paper.

## V / What sort of computer would want this?

The immediate answer is probably not a laptop.

A laptop needs predictable response times, billions of repeated operations, cheap memory, straightforward input and output, and a manufacturing ecosystem that has spent decades learning how to make transistors reliable. DNA is not competing with that on ordinary arithmetic.

The interesting applications are where computation and chemistry already occupy the same world. Imagine a molecular system that responds to several local signals and settles into a configuration that performs a useful sensing or control function. Or a material whose assembly embodies a decision about what structure to form. Or DNA data-storage and molecular-robotics systems in which information processing does not need to leave the chemical medium merely to return as a control signal.

Those are directions suggested by the researchers, not products they have demonstrated. The leap from laboratory scaffold to useful device is large. So is the leap from thermodynamic favourability to a practical claim of lower *whole-system* energy use.

Nevertheless, the experiment changes the question we can ask.

Much of computer engineering is concerned with making a machine obey: more precise clocks, stronger isolation, more error correction, more carefully staged operations. That approach has produced a technological civilisation. But it is not the only conceivable relationship between information and matter.

The Maynooth machine is designed less like a regiment of switches and more like a landscape with one particularly inviting valley. It does not command every molecule to take the correct path. It makes the correct destination attractive enough that the molecules can find it through their own local interactions.

The distinction feels philosophical because it is philosophical. But it is also a working experiment, with numbers, error bars, awkward scale-up problems and a paper anyone can read.

That is why it deserves attention now. Not because DNA has finally defeated silicon. It hasn't. But because a research team has demonstrated a different way to make matter perform an algorithm, and the old assumption that a computer must always be driven through every step looks a little less inevitable.

The future computer may still be a box that gets hot.

It is now easier to imagine another kind: one that does some of its thinking by being allowed to settle down.

---

### Toolbox translated

**Scaffold:** a long DNA strand providing ordered positions to which shorter strands can bind. It is the physical spine of the program.

**Compute tile:** a short DNA strand whose binding regions encode a position and computational relationships with neighbours.

**Thermodynamic equilibrium:** a state in which the system's large-scale properties no longer show a net tendency to change under fixed conditions. Here the researchers design the desired output to be energetically favoured.

**Finite-state machine:** a simple model of computation with a limited number of internal states. Addition can use a carry bit as state passed between digit positions.

**Annealing:** heating and cooling a molecular mixture to let bonds break, reform and settle into more favourable arrangements.

**Yield:** an experimental measure of how much of the expected output signal or structure is obtained. It is not interchangeable with a guarantee of correct answers on every future input.

### Read more / primary shelf

1. [Stérin, Eshra, Evans, Adio & Woods, *A thermodynamically favoured molecular computer*, Nature, 16 September 2026](https://www.nature.com/articles/s41586-026-10996-5). The actual experiment, open access; begin with the figures and discussion.
2. [Maynooth University, research summary](https://www.maynoothuniversity.ie/node/565228). A clear account of the results and intended directions.
3. [Rolf Landauer, *Irreversibility and Heat Generation in the Computing Process* (1961)](https://doi.org/10.1147/RD.53.0183). The older argument about information and physical cost.
4. [Charles H. Bennett, *Logical Reversibility of Computation* (1973)](https://doi.org/10.1147/rd.176.0525). Why logical computation need not destroy information at every step.
5. [Leonard Adleman, *Molecular Computation of Solutions to Combinatorial Problems* (1994)](https://doi.org/10.1126/science.7973651). The early DNA-computing demonstration.
6. [Erik Winfree, *Algorithmic Self-Assembly of DNA* (1998)](https://thesis.caltech.edu/1866/). The conceptual bridge between computation and molecular assembly.
7. [Paul Rothemund, *Folding DNA to Create Nanoscale Shapes and Patterns* (2006)](https://www.nature.com/articles/nature04586). The DNA-origami lineage.

**Evidence boundary:** This is a source-led research feature. Toolglass did not reproduce the laboratory results or independently measure energy consumption. Performance and yields refer to the paper's experimental systems and should not be generalised to useful molecular computers. Artwork is an original conceptual plate, not a molecular structure measured by microscopy.


---

---
title: Mary Allen Wilkes and the Computer in the Living Room
slug: mary-allen-wilkes-and-the-computer-in-the-living-room
section: People
article_type: Person profile
issue_date: 2026-10-19
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SOURCE-CHECKED / DESK-RESEARCHED
hero_art: art/linc-living-room-machine.webp
pull_quotes: 2
---

# Mary Allen Wilkes and the Computer in the Living Room

## She helped build a computer that ordinary researchers could operate for themselves, wrote an astonishing editor in 2,048 words of memory, and then left computing to become the lawyer she had always wanted to be. The famous photograph is only the doorway.

**TOOLGLASS / PEOPLE / OCTOBER 2026**

In 1965, a computer arrived at a house in Baltimore.

Not a little plastic box in a cardboard carton. Not something bought from a shop. Two men brought the machine in a van and installed it in the living room of a clergyman and his wife. It had a keyboard, a display, magnetic tape and a considerable amount of hardware. It was called a **LINC**.

The clergyman was delighted. He went around telling people that he had a computer in his living room, and challenging them to produce one of their own. The neighbours, many of whom had never seen a computer at all, were understandably interested.

But the computer was not really there for him.

It was there for his daughter, **Mary Allen Wilkes**, who was writing an operating system.

The story survives in Wilkes's own [Computer History Museum oral history](https://archive.computerhistory.org/resources/access/text/2024/06/102792262-05-01-acc.pdf). She tells it without much ceremony. Her colleagues in St Louis needed her to finish the software; she did not want to move there immediately; so they sent her the machine. Why not? They were trying to build computers that people could use where they actually worked. A house was simply an unusually domestic laboratory.

It has become common to call Wilkes the first person to use a personal computer at home. That is a reasonable historical shorthand, though 'first' claims in computing are notoriously sensitive to definitions. The LINC was a research machine, not a mass-market home computer, and Wilkes was a professional programmer, not a customer. The more interesting fact is what she was doing with it.

She was building an environment in which the person at the keyboard could control the whole conversation with the machine.

## I / A programmer before there was a profession

Wilkes did not set out to be a computer scientist. She studied philosophy at Wellesley College, graduating in 1959, with a particular interest in logic. She had wanted to practise law since visiting the US Supreme Court as a teenager and being captivated by the structure of legal argument. But people she consulted told her that a woman was unlikely to get into law school, finish, find work, or reach the courtroom she actually wanted.

The advice was both discouraging and, in retrospect, rather revealing about the period. The career that was supposed to be respectable and established was closed to her. Computing, which barely knew what its professional qualifications ought to be, was open.

In her oral history, Wilkes recalls going to MIT's employment office shortly after graduating and asking about programming work. She had no formal programming qualification. Few people did. She was sent to **Lincoln Laboratory**, where she joined an early speech-recognition project led by **Oliver Selfridge** and **Ben Gold**. A more experienced programmer, **Connie McElwain**, taught her the practical work and gave her lifts to the laboratory. Those details matter. Computing history is full of famous laboratory directors and strangely short of the people who showed newcomers how to make the machines do anything.

Programming then could be a long correspondence with an institution. Write instructions on paper. Have them punched onto cards. Submit the deck. Wait for the computer centre. Receive a broad green printout. Find the mistake. Change a card. Submit the deck again.

The logic might be absorbing, but the physical rhythm was miserable. A programmer could spend more time waiting to discover what a program had done than deciding what it ought to do next.

After a year studying music and German in Vienna, Wilkes returned to Lincoln Laboratory in 1961. She was assigned to **Wesley Clark's** computer-design group. Clark was working on something that now seems almost obvious and at the time was not: a computer small enough and direct enough for a scientist to use personally, in the laboratory, without passing every operation through a central computer service.

That machine became the LINC.

## II / A computer that belonged to the person using it

LINC stood for **Laboratory Instrument Computer**. It was developed at MIT in 1962 for scientific and biomedical work. The computer could acquire signals from instruments, show them on a display and let the researcher alter the program while working with the apparatus. Its magnetic **LINCtape** allowed people to keep and carry their own programs and data. The Computer History Museum calls attention to the almost revolutionary social implication: the user's data could fit in a jacket pocket. [Its account of the LINC](https://www.computerhistory.org/revolution/minicomputers/11/334) is worth reading beside Wilkes's memories.

There is a lovely historical collision here. Clark's earlier **TX-2** computer at Lincoln Laboratory was also the machine on which **Ivan Sutherland** built **Sketchpad**, the pioneering interactive drawing system of 1963. One line of work asked what would happen if a designer could draw directly with a computer. Another asked what would happen if a scientist could operate a computer directly beside an experiment. Both were quietly dismantling the idea that computing had to be a remote service mediated by operators. [The Computer History Museum's Sketchpad history](https://computerhistory.org/blog/the-remarkable-ivan-sutherland/) provides the parallel.

Wilkes contributed to the LINC's early software and documentation, and helped teach the scientists who came to learn to build and use the machines. These were not necessarily computer specialists. That was the point. If a researcher needed a programming priesthood standing behind every experiment, the project had failed.

When the LINC team moved to Washington University in St Louis, Wilkes continued the software work from Baltimore. The living-room photograph records the odd location. It does not show the most interesting thing: a design process that treated the user as the centre of the system.

Before specifying the final version of her software, Wilkes visited around ten laboratories using the LINC. She asked what researchers found awkward, what they needed, what slowed them down, and which facilities would make their work easier. This was not a late twentieth-century invention called 'user-centred design'. It was a working programmer taking the trouble to find out what people did with a computer before deciding what the computer should do.

> **PULL QUOTE 01 / TOOLGLASS**  
> The machine was small because the user was meant to be large.

## III / An operating system in almost no memory

By the middle of the 1960s, the LINC's memory had grown to **2,048 words of 12 bits each**. That is 24,576 bits, or roughly three kilobytes if one makes a rough modern conversion. The comparison is useful for shock value, but it is not a perfect translation of an old machine's memory architecture into today's bytes.

Wilkes called the resulting system **LAP6**, the sixth major LINC Assembly Program. It combined editing, filing, assembly and other functions in an interactive environment. Her 1970 paper was titled *Conversational Access to a 2048-Word Machine*. The title is not marketing. It describes an ambition.

The user could prepare source text, see it on the scope, move through it, change it, assemble it and manage files. The system's editing method treated text as a **scroll** on magnetic tape. Only a small portion needed to be in main memory at once. A local editing area allowed characters to be inserted and removed without rebuilding the whole document in memory. Her technical paper discusses strings of **23,040 characters**, managed on a machine whose memory was far smaller than the text it could edit. [The original *Scroll Editing* paper](https://www.digibarn.com/stories/linc/documents/LINC-Mary-Allen-Wilkes/Scroll-Editing-Proc.-IEEE.pdf) and [*Conversational Access*](https://worrydream.com/refs/Wilkes_1970_-_Conversational_Access_to_a_2048-Word_Machine.pdf) are wonderfully concrete reading.

The word *scroll* is not a quaint metaphor pasted onto a modern interface. It describes the relationship between the visible text, the tape transport and the editing algorithm. The document moved across a display; the user worked at a point of interest; the system managed the consequences. Wilkes's editor was an exercise in making an expensive physical constraint disappear from the user's immediate attention.

That is what good software often does. It does not abolish the machine's limitations. It arranges them so that the person can think about the work rather than the limitations.

LAP6 also contained an assembler and ways to manage and retrieve programs. The LINC's tape format and file-handling conventions mattered because a scientist needed not just to type code, but to keep it, find it, share it and return to it. It is tempting to describe this as an early integrated development environment. That is a useful analogy, but it should remain an analogy. The hardware, workflow and institutional setting were different.

The deeper achievement was to treat editing, program preparation and use as parts of one activity. The person at the machine did not have to surrender control after every change.

## IV / The road not taken by the industry

A great deal of computing history is told as a procession of machines getting smaller: room-sized mainframe, minicomputer, microcomputer, laptop, phone. The LINC complicates that story. Its importance was not merely its dimensions. It represented a different arrangement of authority and attention.

Who gets to operate the machine? Who owns the program and data? How quickly can an idea be tested? Can the researcher interrupt the process, inspect what happened and change course? These are questions about the experience of computing, not just transistor counts.

The LINC did not become a household consumer platform. It belonged to laboratories, and its specialised instrumentation was part of the attraction. Its descendants and contemporaries led in several directions, including Digital Equipment Corporation's minicomputer world. Meanwhile, the personal-computer market of the 1970s and 1980s would give millions of people machines that were smaller and cheaper, but not necessarily as coherent or considerate as the environment Wilkes was trying to build.

The strange thing about LAP6 is how familiar its priorities remain. Reduce waiting. Keep work visible. Make editing reversible enough to encourage experiment. Let users maintain their own files. Put related actions in a comprehensible place. Discover what the people using the machine actually need.

This is not nostalgia for magnetic tape. It is an argument that interface quality does not arrive automatically with faster processors. You can have gigabytes of memory and still make the user feel as if they are sending punch cards to a distant department.

> **PULL QUOTE 02 / TOOLGLASS**  
> A personal computer is not defined only by where it sits, but by who is allowed to act.

## V / The second career was the first ambition

The usual biographical version of this story would end with Wilkes receiving an award and computing finally recognising a pioneer. Her actual life is more interesting because she left.

After roughly eleven years in the field, she went to **Harvard Law School** in 1972 and became a lawyer. She practised for decades, including courtroom work and arbitration, returning to the intellectual discipline that had captivated her as a teenager. She also worked on disputes involving technology, which gave the two careers an occasional practical overlap. Her [James Madison University biography](https://digital.cs.jmu.edu/2018/wilkes.html) records the legal work without treating it as a strange footnote to a 'real' life in computers.

The decision can look like an exit from history only if we assume that history's job is to keep people in the profession that later generations find most interesting. Wilkes did not owe computing another thirty years. She had helped make a machine more usable, written demanding systems software, worked on hardware modules and left behind technical papers that can still teach designers how to think.

Her oral history also contains an irony she recognises herself. In the 1950s she was warned that becoming a woman trial lawyer would mean being a pioneer, which she did not particularly want. Computing offered a route into serious technical work without quite the same professional barriers, partly because the field was still inventing itself. Later, people would call her a computing pioneer anyway.

There is no need to tidy that irony into a moral. She wanted to work on interesting problems. For a time the interesting problem was how to make a tiny machine serve its user. Later it was how to reason, argue and practise law.

The computer in the Baltimore living room is a wonderful photograph, and one can hardly blame historians for loving it. But the photograph is not the achievement. It is the scene in which the achievement happened.

The achievement was a computer that listened when the person at the keyboard changed her mind.

And a programmer who was quite prepared to change hers.

---

### Toolbox translated

**LINC:** Laboratory Instrument Computer, a small, interactive 1960s machine for scientists, particularly useful for collecting and analysing instrument signals.

**TX-2:** an experimental transistor computer at MIT Lincoln Laboratory. Its interactive display and input facilities made it a home for early graphical computing, including Sketchpad.

**LINCtape:** a small, removable magnetic-tape medium used to store and exchange programs and data. Its logical access patterns helped make interactive editing practical.

**LAP6:** Mary Allen Wilkes's interactive assembly, editing and filing system for the LINC. 'Operating system' is a useful term here, but the boundaries of software systems in the 1960s differed from today's.

**Scroll editing:** an approach to text manipulation that treated a long document as a moving scroll on tape, with a small active editing region held in memory.

**Assembler:** a program that translates symbolic machine instructions into the numerical instructions the processor can execute.

**Macromodules:** modular hardware building blocks developed after the LINC project. Wilkes worked on a multiplication module, a reminder that her contributions were not limited to software.

### Read more / primary shelf

1. [Computer History Museum, *Oral History of Mary Allen Wilkes*, part 1, recorded 28 July 2021](https://archive.computerhistory.org/resources/access/text/2024/06/102792262-05-01-acc.pdf). Her own voice on the living-room LINC, the people she worked with and her path into computing.
2. [Wilkes, *Conversational Access to a 2048-Word Machine*, Communications of the ACM, July 1970](https://worrydream.com/refs/Wilkes_1970_-_Conversational_Access_to_a_2048-Word_Machine.pdf). The system explained by its designer.
3. [Wilkes, *Scroll Editing: An On-Line Algorithm for Manipulating Long Character Strings*, IEEE, November 1970](https://www.digibarn.com/stories/linc/documents/LINC-Mary-Allen-Wilkes/Scroll-Editing-Proc.-IEEE.pdf). An unusually lucid piece of interface engineering.
4. [Computer History Museum, *A New Approach to Computers: The First PC?*](https://www.computerhistory.org/revolution/minicomputers/11/334). LINC's place in the history of personal computing.
5. [Computer History Museum, *The Remarkable Ivan Sutherland*](https://computerhistory.org/blog/the-remarkable-ivan-sutherland/). The TX-2 and the neighbouring history of direct interaction.
6. [Heinz Nixdorf MuseumsForum, *The LINC to PC*](https://www.hnf.de/en/permanent-exhibition/exhibition-areas/computers-in-science-and-technology-1950-to-1970/the-linc-to-pc.html). A museum account of the machine and its arrival in a home.
7. [James Madison University, Mary Allen Wilkes biography](https://digital.cs.jmu.edu/2018/wilkes.html). The computing career and the long legal one that followed.

**Evidence boundary:** Source-led historical profile, not an interview conducted by Toolglass. The two pull quotes above are **original Toolglass editorial lines**, not statements attributed to Wilkes. 'First home personal computer user' is presented as a commonly accepted description, not an unqualified universal priority claim. The artwork is an invented conceptual drawing, not a likeness or a reproduction of a historical photograph.
