---
title: Mary Allen Wilkes and the Computer in the Living Room
slug: mary-allen-wilkes-and-the-computer-in-the-living-room
section: People
article_type: Person profile
issue_date: 2026-10-19
status: DRAFT — FOR MATTHEW'S REVIEW
evidence_status: SOURCE-CHECKED / DESK-RESEARCHED
hero_art: art/linc-living-room-machine.webp
pull_quotes: 2
---

# Mary Allen Wilkes and the Computer in the Living Room

## She helped build a computer that ordinary researchers could operate for themselves, wrote an astonishing editor in 2,048 words of memory, and then left computing to become the lawyer she had always wanted to be. The famous photograph is only the doorway.

**TOOLGLASS / PEOPLE / OCTOBER 2026**

In 1965, a computer arrived at a house in Baltimore.

Not a little plastic box in a cardboard carton. Not something bought from a shop. Two men brought the machine in a van and installed it in the living room of a clergyman and his wife. It had a keyboard, a display, magnetic tape and a considerable amount of hardware. It was called a **LINC**.

The clergyman was delighted. He went around telling people that he had a computer in his living room, and challenging them to produce one of their own. The neighbours, many of whom had never seen a computer at all, were understandably interested.

But the computer was not really there for him.

It was there for his daughter, **Mary Allen Wilkes**, who was writing an operating system.

The story survives in Wilkes's own [Computer History Museum oral history](https://archive.computerhistory.org/resources/access/text/2024/06/102792262-05-01-acc.pdf). She tells it without much ceremony. Her colleagues in St Louis needed her to finish the software; she did not want to move there immediately; so they sent her the machine. Why not? They were trying to build computers that people could use where they actually worked. A house was simply an unusually domestic laboratory.

It has become common to call Wilkes the first person to use a personal computer at home. That is a reasonable historical shorthand, though 'first' claims in computing are notoriously sensitive to definitions. The LINC was a research machine, not a mass-market home computer, and Wilkes was a professional programmer, not a customer. The more interesting fact is what she was doing with it.

She was building an environment in which the person at the keyboard could control the whole conversation with the machine.

## I / A programmer before there was a profession

Wilkes did not set out to be a computer scientist. She studied philosophy at Wellesley College, graduating in 1959, with a particular interest in logic. She had wanted to practise law since visiting the US Supreme Court as a teenager and being captivated by the structure of legal argument. But people she consulted told her that a woman was unlikely to get into law school, finish, find work, or reach the courtroom she actually wanted.

The advice was both discouraging and, in retrospect, rather revealing about the period. The career that was supposed to be respectable and established was closed to her. Computing, which barely knew what its professional qualifications ought to be, was open.

In her oral history, Wilkes recalls going to MIT's employment office shortly after graduating and asking about programming work. She had no formal programming qualification. Few people did. She was sent to **Lincoln Laboratory**, where she joined an early speech-recognition project led by **Oliver Selfridge** and **Ben Gold**. A more experienced programmer, **Connie McElwain**, taught her the practical work and gave her lifts to the laboratory. Those details matter. Computing history is full of famous laboratory directors and strangely short of the people who showed newcomers how to make the machines do anything.

Programming then could be a long correspondence with an institution. Write instructions on paper. Have them punched onto cards. Submit the deck. Wait for the computer centre. Receive a broad green printout. Find the mistake. Change a card. Submit the deck again.

The logic might be absorbing, but the physical rhythm was miserable. A programmer could spend more time waiting to discover what a program had done than deciding what it ought to do next.

After a year studying music and German in Vienna, Wilkes returned to Lincoln Laboratory in 1961. She was assigned to **Wesley Clark's** computer-design group. Clark was working on something that now seems almost obvious and at the time was not: a computer small enough and direct enough for a scientist to use personally, in the laboratory, without passing every operation through a central computer service.

That machine became the LINC.

## II / A computer that belonged to the person using it

LINC stood for **Laboratory Instrument Computer**. It was developed at MIT in 1962 for scientific and biomedical work. The computer could acquire signals from instruments, show them on a display and let the researcher alter the program while working with the apparatus. Its magnetic **LINCtape** allowed people to keep and carry their own programs and data. The Computer History Museum calls attention to the almost revolutionary social implication: the user's data could fit in a jacket pocket. [Its account of the LINC](https://www.computerhistory.org/revolution/minicomputers/11/334) is worth reading beside Wilkes's memories.

There is a lovely historical collision here. Clark's earlier **TX-2** computer at Lincoln Laboratory was also the machine on which **Ivan Sutherland** built **Sketchpad**, the pioneering interactive drawing system of 1963. One line of work asked what would happen if a designer could draw directly with a computer. Another asked what would happen if a scientist could operate a computer directly beside an experiment. Both were quietly dismantling the idea that computing had to be a remote service mediated by operators. [The Computer History Museum's Sketchpad history](https://computerhistory.org/blog/the-remarkable-ivan-sutherland/) provides the parallel.

Wilkes contributed to the LINC's early software and documentation, and helped teach the scientists who came to learn to build and use the machines. These were not necessarily computer specialists. That was the point. If a researcher needed a programming priesthood standing behind every experiment, the project had failed.

When the LINC team moved to Washington University in St Louis, Wilkes continued the software work from Baltimore. The living-room photograph records the odd location. It does not show the most interesting thing: a design process that treated the user as the centre of the system.

Before specifying the final version of her software, Wilkes visited around ten laboratories using the LINC. She asked what researchers found awkward, what they needed, what slowed them down, and which facilities would make their work easier. This was not a late twentieth-century invention called 'user-centred design'. It was a working programmer taking the trouble to find out what people did with a computer before deciding what the computer should do.

> **PULL QUOTE 01 / TOOLGLASS**  
> The machine was small because the user was meant to be large.

## III / An operating system in almost no memory

By the middle of the 1960s, the LINC's memory had grown to **2,048 words of 12 bits each**. That is 24,576 bits, or roughly three kilobytes if one makes a rough modern conversion. The comparison is useful for shock value, but it is not a perfect translation of an old machine's memory architecture into today's bytes.

Wilkes called the resulting system **LAP6**, the sixth major LINC Assembly Program. It combined editing, filing, assembly and other functions in an interactive environment. Her 1970 paper was titled *Conversational Access to a 2048-Word Machine*. The title is not marketing. It describes an ambition.

The user could prepare source text, see it on the scope, move through it, change it, assemble it and manage files. The system's editing method treated text as a **scroll** on magnetic tape. Only a small portion needed to be in main memory at once. A local editing area allowed characters to be inserted and removed without rebuilding the whole document in memory. Her technical paper discusses strings of **23,040 characters**, managed on a machine whose memory was far smaller than the text it could edit. [The original *Scroll Editing* paper](https://www.digibarn.com/stories/linc/documents/LINC-Mary-Allen-Wilkes/Scroll-Editing-Proc.-IEEE.pdf) and [*Conversational Access*](https://worrydream.com/refs/Wilkes_1970_-_Conversational_Access_to_a_2048-Word_Machine.pdf) are wonderfully concrete reading.

The word *scroll* is not a quaint metaphor pasted onto a modern interface. It describes the relationship between the visible text, the tape transport and the editing algorithm. The document moved across a display; the user worked at a point of interest; the system managed the consequences. Wilkes's editor was an exercise in making an expensive physical constraint disappear from the user's immediate attention.

That is what good software often does. It does not abolish the machine's limitations. It arranges them so that the person can think about the work rather than the limitations.

LAP6 also contained an assembler and ways to manage and retrieve programs. The LINC's tape format and file-handling conventions mattered because a scientist needed not just to type code, but to keep it, find it, share it and return to it. It is tempting to describe this as an early integrated development environment. That is a useful analogy, but it should remain an analogy. The hardware, workflow and institutional setting were different.

The deeper achievement was to treat editing, program preparation and use as parts of one activity. The person at the machine did not have to surrender control after every change.

## IV / The road not taken by the industry

A great deal of computing history is told as a procession of machines getting smaller: room-sized mainframe, minicomputer, microcomputer, laptop, phone. The LINC complicates that story. Its importance was not merely its dimensions. It represented a different arrangement of authority and attention.

Who gets to operate the machine? Who owns the program and data? How quickly can an idea be tested? Can the researcher interrupt the process, inspect what happened and change course? These are questions about the experience of computing, not just transistor counts.

The LINC did not become a household consumer platform. It belonged to laboratories, and its specialised instrumentation was part of the attraction. Its descendants and contemporaries led in several directions, including Digital Equipment Corporation's minicomputer world. Meanwhile, the personal-computer market of the 1970s and 1980s would give millions of people machines that were smaller and cheaper, but not necessarily as coherent or considerate as the environment Wilkes was trying to build.

The strange thing about LAP6 is how familiar its priorities remain. Reduce waiting. Keep work visible. Make editing reversible enough to encourage experiment. Let users maintain their own files. Put related actions in a comprehensible place. Discover what the people using the machine actually need.

This is not nostalgia for magnetic tape. It is an argument that interface quality does not arrive automatically with faster processors. You can have gigabytes of memory and still make the user feel as if they are sending punch cards to a distant department.

> **PULL QUOTE 02 / TOOLGLASS**  
> A personal computer is not defined only by where it sits, but by who is allowed to act.

## V / The second career was the first ambition

The usual biographical version of this story would end with Wilkes receiving an award and computing finally recognising a pioneer. Her actual life is more interesting because she left.

After roughly eleven years in the field, she went to **Harvard Law School** in 1972 and became a lawyer. She practised for decades, including courtroom work and arbitration, returning to the intellectual discipline that had captivated her as a teenager. She also worked on disputes involving technology, which gave the two careers an occasional practical overlap. Her [James Madison University biography](https://digital.cs.jmu.edu/2018/wilkes.html) records the legal work without treating it as a strange footnote to a 'real' life in computers.

The decision can look like an exit from history only if we assume that history's job is to keep people in the profession that later generations find most interesting. Wilkes did not owe computing another thirty years. She had helped make a machine more usable, written demanding systems software, worked on hardware modules and left behind technical papers that can still teach designers how to think.

Her oral history also contains an irony she recognises herself. In the 1950s she was warned that becoming a woman trial lawyer would mean being a pioneer, which she did not particularly want. Computing offered a route into serious technical work without quite the same professional barriers, partly because the field was still inventing itself. Later, people would call her a computing pioneer anyway.

There is no need to tidy that irony into a moral. She wanted to work on interesting problems. For a time the interesting problem was how to make a tiny machine serve its user. Later it was how to reason, argue and practise law.

The computer in the Baltimore living room is a wonderful photograph, and one can hardly blame historians for loving it. But the photograph is not the achievement. It is the scene in which the achievement happened.

The achievement was a computer that listened when the person at the keyboard changed her mind.

And a programmer who was quite prepared to change hers.

---

### Toolbox translated

**LINC:** Laboratory Instrument Computer, a small, interactive 1960s machine for scientists, particularly useful for collecting and analysing instrument signals.

**TX-2:** an experimental transistor computer at MIT Lincoln Laboratory. Its interactive display and input facilities made it a home for early graphical computing, including Sketchpad.

**LINCtape:** a small, removable magnetic-tape medium used to store and exchange programs and data. Its logical access patterns helped make interactive editing practical.

**LAP6:** Mary Allen Wilkes's interactive assembly, editing and filing system for the LINC. 'Operating system' is a useful term here, but the boundaries of software systems in the 1960s differed from today's.

**Scroll editing:** an approach to text manipulation that treated a long document as a moving scroll on tape, with a small active editing region held in memory.

**Assembler:** a program that translates symbolic machine instructions into the numerical instructions the processor can execute.

**Macromodules:** modular hardware building blocks developed after the LINC project. Wilkes worked on a multiplication module, a reminder that her contributions were not limited to software.

### Read more / primary shelf

1. [Computer History Museum, *Oral History of Mary Allen Wilkes*, part 1, recorded 28 July 2021](https://archive.computerhistory.org/resources/access/text/2024/06/102792262-05-01-acc.pdf). Her own voice on the living-room LINC, the people she worked with and her path into computing.
2. [Wilkes, *Conversational Access to a 2048-Word Machine*, Communications of the ACM, July 1970](https://worrydream.com/refs/Wilkes_1970_-_Conversational_Access_to_a_2048-Word_Machine.pdf). The system explained by its designer.
3. [Wilkes, *Scroll Editing: An On-Line Algorithm for Manipulating Long Character Strings*, IEEE, November 1970](https://www.digibarn.com/stories/linc/documents/LINC-Mary-Allen-Wilkes/Scroll-Editing-Proc.-IEEE.pdf). An unusually lucid piece of interface engineering.
4. [Computer History Museum, *A New Approach to Computers: The First PC?*](https://www.computerhistory.org/revolution/minicomputers/11/334). LINC's place in the history of personal computing.
5. [Computer History Museum, *The Remarkable Ivan Sutherland*](https://computerhistory.org/blog/the-remarkable-ivan-sutherland/). The TX-2 and the neighbouring history of direct interaction.
6. [Heinz Nixdorf MuseumsForum, *The LINC to PC*](https://www.hnf.de/en/permanent-exhibition/exhibition-areas/computers-in-science-and-technology-1950-to-1970/the-linc-to-pc.html). A museum account of the machine and its arrival in a home.
7. [James Madison University, Mary Allen Wilkes biography](https://digital.cs.jmu.edu/2018/wilkes.html). The computing career and the long legal one that followed.

**Evidence boundary:** Source-led historical profile, not an interview conducted by Toolglass. The two pull quotes above are **original Toolglass editorial lines**, not statements attributed to Wilkes. 'First home personal computer user' is presented as a commonly accepted description, not an unqualified universal priority claim. The artwork is an invented conceptual drawing, not a likeness or a reproduction of a historical photograph.
