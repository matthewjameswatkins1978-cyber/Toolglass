#!/usr/bin/env python3
"""Original, editable Toolglass concept plates, drawn with local vector tooling.
No image-generation model or remote assets. Inspired by the existing Toolglass
machine-folklore SVG vocabulary: paper, plotter lines, cobalt, lime, spare type.
"""
import math, random, subprocess
from pathlib import Path
import svgwrite
from PIL import Image, ImageOps, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'; ART.mkdir(parents=True,exist_ok=True)
W,H=1536,1024
PAPER='#eee9dc'; INK='#202522'; BLUE='#1748a0'; LIGHT='#6683b7'; GREY='#8d8e80'; LIME='#c4ef32'; WHITE='#f9f6ed'

def init(name, title, desc, plate):
    d=svgwrite.Drawing(str(ART/name), size=(W,H), viewBox=f'0 0 {W} {H}', profile='full')
    d.add(svgwrite.base.Title(title)); d.add(svgwrite.base.Desc(desc))
    d.add(d.rect(insert=(0,0),size=(W,H),fill=PAPER))
    rng=random.Random(63)
    for i in range(430):
        x=rng.uniform(55,W-55); y=rng.uniform(60,H-55)
        d.add(d.circle(center=(x,y),r=.64,fill=INK,opacity=.085))
    d.add(d.text(f'TOOLGLASS / MACHINE FOLKLORE / {plate}',insert=(87,83),fill=BLUE,font_size=14,font_family='DejaVu Sans Mono',letter_spacing=2))
    for x,y,sgn in [(105,120,1),(1431,120,-1),(105,900,1),(1431,900,-1)]:
        d.add(d.line((x-22,y),(x+22,y),stroke=GREY,stroke_width=1))
        d.add(d.line((x,y-22),(x,y+22),stroke=GREY,stroke_width=1))
    d.add(d.rect(insert=(95,847),size=(21,21),fill=BLUE))
    d.add(d.rect(insert=(129,847),size=(21,21),fill=LIME,stroke=INK,stroke_width=2))
    d.add(d.text('19 / X / 2026',insert=(1325,954),fill=GREY,font_size=13,font_family='DejaVu Sans Mono',letter_spacing=1.4))
    return d

def txt(d,s,x,y,size=16,color=BLUE,spacing=1.4,anchor='start'):
    d.add(d.text(s,insert=(x,y),fill=color,font_size=size,font_family='DejaVu Sans Mono',letter_spacing=spacing,text_anchor=anchor))

def rect(d,x,y,w,h,stroke=INK,sw=2,fill='none'):
    d.add(d.rect(insert=(x,y),size=(w,h),fill=fill,stroke=stroke,stroke_width=sw))

def line(d,x1,y1,x2,y2,color=GREY,sw=1,dash=None):
    opts={'stroke':color,'stroke_width':sw}
    if dash:opts['stroke_dasharray']=dash
    d.add(d.line((x1,y1),(x2,y2),**opts))

def equilibrium():
    d=init('equilibrium-machine.svg','The computer that wanted to settle down','A conceptual technical plate: DNA-like competing tiles settle on a scaffold; an adjacent energy landscape falls into one lime-coloured basin. Not an actual molecular structure.','EQUILIBRIUM 01')
    txt(d,'SCAFFOLD / COMPETING INSTRUCTIONS',117,213,17,BLUE,1.1)
    txt(d,'STATE SPACE',1042,213,17,BLUE,1.6)
    # A long molecular rail across the paper
    rect(d,111,285,844,445,INK,2)
    for i in range(9):
        x=173+i*86
        line(d,x,309,x,701,GREY,1,'3,8')
    line(d,143,515,925,515,INK,8)
    line(d,143,529,925,529,BLUE,3)
    # Tile seats on scaffold: some correct, some floating alternatives
    rng=random.Random(18)
    for i in range(8):
        x=167+i*93
        y=419 + (i%2)*8
        # loose alternatives above: visually unstable
        rect(d,x-18,318+(i%3)*12,74,43,GREY,1)
        line(d,x-8,342+(i%3)*12,x+43,342+(i%3)*12,GREY,1)
        d.add(d.circle(center=(x+18,340+(i%3)*12),r=6,fill=WHITE,stroke=GREY,stroke_width=1))
        # bound tile: interface to rail
        rect(d,x-18,y,74,95,BLUE,2,WHITE)
        d.add(d.rect(insert=(x-8,y+12),size=(54,12),fill=BLUE if i%3 else LIME))
        for k in range(3):
            d.add(d.circle(center=(x-4+20*k,y+55),r=5,fill=BLUE if (i+k)%3 else LIME,stroke=INK,stroke_width=.7))
        line(d,x+18,y+95,x+18,515,BLUE,2)
        # neighbouring computation edges
        if i<7:
            line(d,x+56,y+71,x+75,426+((i+1)%2)*8+71,BLUE,2)
    txt(d,'A / INPUT',152,755,14,BLUE,1.5)
    txt(d,'B / BIND',466,755,14,BLUE,1.5)
    txt(d,'C / REPLACE',782,755,14,BLUE,1.5)
    # central transfer / separator
    d.add(d.path(d='M 960 520 C 1000 520 1002 620 1044 620',fill='none',stroke=BLUE,stroke_width=4))
    d.add(d.circle(center=(1005,560),r=7,fill=LIME,stroke=INK,stroke_width=2))
    # Landscape panel
    rect(d,1020,285,392,445,INK,2)
    # Nested contours like an energetic topographic depression
    for j in range(7):
        cx=1218; cy=523
        rx=169-j*21; ry=172-j*21
        d.add(d.ellipse(center=(cx,cy),r=(rx,ry),fill='none',stroke=LIGHT if j%2 else INK,stroke_width=1.5,opacity=.9))
    # nonuniform perturbations around basin
    for a in range(0,360,22):
        rad=math.radians(a)
        x=1218+170*math.cos(rad); y=523+169*math.sin(rad)
        line(d,x-5,y-5,x+5,y+5,GREY,1)
    d.add(d.circle(center=(1218,523),r=30,fill=LIME,stroke=INK,stroke_width=3))
    d.add(d.circle(center=(1218,523),r=8,fill=BLUE))
    txt(d,'LOWEST',1218,770,15,BLUE,1.4,'middle')
    txt(d,'ENERGY',1218,794,15,BLUE,1.4,'middle')
    # Technical paper footer
    txt(d,'A PROGRAM WRITTEN AS PREFERENCE, NOT A CLOCK.',260,870,17,INK,1.7)
    txt(d,'FIG. 01 / CONCEPTUAL, NOT A MOLECULAR MICROGRAPH',259,917,12,GREY,1.2)
    d.save()

def linc():
    d=init('linc-living-room-machine.svg','Mary Allen Wilkes inside the LINC','A conceptual 1965 living-room plan: a small programmer sits within the working system of console, tapes and scrolling text, with no heroic portrait or historical photo reproduction.','PERSON INSIDE SYSTEM 02')
    # Architectural frame and room
    rect(d,125,208,1276,588,INK,3)
    # double line wall, deliberate doorway on left
    line(d,145,228,1380,228,GREY,1)
    line(d,145,776,1380,776,GREY,1)
    txt(d,'BALTIMORE / 1965',168,267,16,BLUE,1.7)
    txt(d,'ROOM 01',1197,267,15,BLUE,1.7)
    # room floor grid subtle
    for x in range(175,1370,62):line(d,x,299,x,752,GREY,.6,'1,10')
    for y in range(305,756,62):line(d,170,y,1364,y,GREY,.6,'1,10')
    # door, plant, lamp: domestic not theatrical
    line(d,126,545,126,650,PAPER,9)
    d.add(d.path(d='M 126 650 Q 240 650 240 535',stroke=GREY,stroke_width=2,fill='none'))
    d.add(d.path(d='M 126 650 L 239 650',stroke=BLUE,stroke_width=3,fill='none'))
    # living-room sofa left
    rect(d,182,354,275,115,INK,3,WHITE)
    rect(d,197,370,244,70,GREY,1)
    line(d,316,373,316,438,GREY,1)
    rect(d,178,335,34,150,INK,2,WHITE)
    rect(d,429,335,34,150,INK,2,WHITE)
    txt(d,'DOMESTIC',192,504,13,GREY,1.3)
    # lamp
    line(d,260,584,260,693,INK,4)
    d.add(d.path(d='M 212 585 L 308 585 L 282 539 L 238 539 Z',stroke=INK,stroke_width=2,fill=WHITE))
    line(d,227,695,293,695,INK,3)
    # LINC console main right: vertical racks + display
    rect(d,760,322,521,339,INK,4,WHITE)
    rect(d,777,341,183,244,INK,2,PAPER)
    for x in range(790,946,21):
        for y in range(358,555,22):
            d.add(d.circle(center=(x,y),r=3,fill=BLUE if (x+y)%5 else GREY,opacity=.75))
    txt(d,'LINC',816,618,17,BLUE,2)
    rect(d,982,340,266,177,INK,3,PAPER)
    # CRT with phosphor-like line editor, not a literal reproduction
    rect(d,1004,362,222,131,BLUE,2,INK)
    for j,l in enumerate([150,182,124,176,91]):
        line(d,1024,385+j*19,1024+l,385+j*19,LIME if j==2 else LIGHT,2.8)
    d.add(d.circle(center=(1215,476),r=4,fill=LIME))
    # controls and reels
    for x in (1040,1145):
        d.add(d.circle(center=(x,567),r=39,fill=WHITE,stroke=INK,stroke_width=3))
        d.add(d.circle(center=(x,567),r=12,fill=PAPER,stroke=BLUE,stroke_width=3))
        for a in range(0,360,90):
            ra=math.radians(a);line(d,x+18*math.cos(ra),567+18*math.sin(ra),x+31*math.cos(ra),567+31*math.sin(ra),BLUE,3)
    # Tape linking reels and editing scroll
    d.add(d.path(d='M 1040 526 C 1048 504 1145 505 1145 526',fill='none',stroke=BLUE,stroke_width=2))
    txt(d,'TAPE / TEXT / MEMORY',802,698,16,BLUE,1.4)
    # small programmer inside system, not portrait
    d.add(d.circle(center=(634,417),r=38,fill=PAPER,stroke=INK,stroke_width=3))
    d.add(d.path(d='M 604 409 Q 626 377 657 404',fill='none',stroke=INK,stroke_width=3))
    d.add(d.circle(center=(622,420),r=3,fill=INK));d.add(d.circle(center=(648,420),r=3,fill=INK))
    d.add(d.path(d='M 604 459 Q 631 446 663 458 L 699 573 L 569 573 Z',fill=WHITE,stroke=INK,stroke_width=3))
    # arms at keyboard
    d.add(d.path(d='M 584 498 Q 592 549 655 556',fill='none',stroke=INK,stroke_width=8))
    d.add(d.path(d='M 670 493 Q 698 531 723 549',fill='none',stroke=INK,stroke_width=8))
    rect(d,588,558,149,40,INK,2,PAPER)
    for x in range(600,725,15):line(d,x,572,x+8,572,BLUE,2)
    # a line between person and display, showing conversation
    d.add(d.path(d='M 728 534 C 760 519 784 484 980 427',fill='none',stroke=BLUE,stroke_width=4))
    d.add(d.circle(center=(838,477),r=8,fill=LIME,stroke=INK,stroke_width=2))
    # floor: scroll of text, long enough to leave room
    rect(d,330,719,790,43,BLUE,2,WHITE)
    for i in range(40):
        x=345+i*18
        line(d,x,733,x+11,733,BLUE if i%7 else INK,1.2)
        line(d,x,746,x+7,746,GREY,1)
    txt(d,'SCROLL EDITOR',1150,746,14,BLUE,1.4)
    txt(d,'A PERSON INSIDE THE IDEA, NOT IN FRONT OF IT.',281,875,16,INK,1.5)
    txt(d,'FIG. 02 / CONCEPT PLATE, NOT A HISTORICAL RECONSTRUCTION',280,917,12,GREY,1.2)
    d.save()

def render():
    for stem in ['equilibrium-machine','linc-living-room-machine']:
        svg=ART/f'{stem}.svg'; png=ART/f'{stem}.png'; webp=ART/f'{stem}.webp'
        subprocess.run(['inkscape',str(svg),'--export-filename='+str(png),'--export-width=1536'],check=True,stdout=subprocess.DEVNULL)
        im=Image.open(png).convert('RGB')
        im.save(webp,'WEBP',quality=90,method=6)
        png.unlink()
    imgs=[Image.open(ART/f'{s}.webp').convert('RGB') for s in ['equilibrium-machine','linc-living-room-machine']]
    canvas=Image.new('RGB',(1280,940),'#e7e2d6')
    for i,im in enumerate(imgs):
        im.thumbnail((1170,390),Image.Resampling.LANCZOS)
        canvas.paste(im,((1280-im.width)//2,45+i*450))
    canvas.save(ART/'contact-sheet.webp','WEBP',quality=92)

if __name__=='__main__':
    equilibrium();linc();render()
    for p in ART.iterdir():print(p.name,p.stat().st_size)
