# Toolglass / production handoff / 19 October 2026

## Local Luna mission

Read this bundle, the canonical Toolglass repository's `editorial/house-style/*`, the Joe Armstrong article, and the existing **rendered** magazine pages and artwork on the Windows machine. Compare the two SVG/WebP proposals with the current visual system before accepting them. Do not use image generation. Use the existing local vector/graphic software and existing site asset pipeline, reuse established tooling, and adjust or redraw the plates if the actual rendered Toolglass examples suggest a better treatment. Preserve editable SVG masters and website-optimised exports.

Art direction: paper `#eee9dc`, ink `#202522`, cobalt `#1748a0`, secondary blue `#6683b7`, lime `#c4ef32`, minimal type, spare machine-folklore geometry, restrained technical lines. This palette was read directly from existing Toolglass SVG source. Avoid shiny gradients, faux photographs, AI-gloss, generic heroic portraits and diagrams that make unverified technical claims.

**Plate 1:** DNA tiles competing along a scaffold and a single low-energy basin. Caption: *A computation designed as an energy landscape. Conceptual illustration, not molecular imaging.* Alt: *An editorial technical drawing shows rows of competing DNA-like tiles attached to a long scaffold and a series of nested contours converging on a lime-coloured low-energy state.*

**Plate 2:** a small programmer inside a room-sized working system with LINC-inspired console, tape reels, text scroll, sofa and lamp. Caption: *A computer enters a home; the person at the keyboard remains the centre of the system. Concept plate, not a reconstruction of the 1965 room.* Alt: *A spare floor-plan-style illustration places a seated programmer between a living-room sofa and a LINC-inspired console, with tape reels and a scrolling text strip connecting the scene.*

## Editorial gates

1. Check the Joe Armstrong and Cynthia Solomon pages for typography, rhythm, pull-quote treatment and responsive layout. Person profile has **exactly two** prominent pull quotes, both original editorial statements, with small attribution and generous space, not cards.
2. Confirm all primary-source links resolve; check facts against sources and keep the dated evidence boundaries. Do not turn SCOUTED into TESTED.
3. Confirm Doop licence and account-use caveats, OCUDU hardware-test caveats, and the DNA paper's energy/scale caveats. No 'free energy' or 'replaces silicon' framing.
4. Integrate only after Matthew's editorial review. Use existing typed site content model and source citation conventions; do not create a new CMS or markdown publishing system.
5. Run the site's typecheck, build, lint/known-baseline review, responsive visual inspection and link checks before any publication. Publishing remains **disabled** for this bundle unless Matthew subsequently approves it.

## Rebuild artwork

On a machine with Python, `svgwrite`, `Pillow` and Inkscape available, run:

`python production/build_art.py`

The script writes the editable SVGs, WebP exports and contact sheet to `art/`. It is deterministic. This session used a Linux Inkscape renderer, not Matthew's local Windows graphics setup.
